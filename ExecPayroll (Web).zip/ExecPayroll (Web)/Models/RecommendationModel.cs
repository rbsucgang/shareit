﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace ExecPayroll_Web.Models
{
    public class RecommendationModel
    {                
        public DateTime LastPromoDate { get; set; }
        public string EvaluationDate { get; set; }
        public string LMOVENAT { get; set; }
        public string PAR_C { get; set; }
        public double PAR_N { get; set; }
        public string BAREA { get; set; }
        public string BELLAREA { get; set; }
        public string BELLPOS { get; set; }
        public string BELLPOSDESC { get; set; }        
        public bool TagProlonged { get; set; }
        public bool TagException { get; set; }
        public bool TagVP { get; set; }
        public DateTime TagVPDate { get; set; }
        public DateTime EffectivityDate { get; set; }
        public DateTime Todate { get; set; }
        public decimal CutMos2 { get; set; }
        public decimal CutDays2 { get; set; }
        public bool IsProrated { get; set; }
        public bool TagAdvance { get; set; }
        public string  Recomd { get; set; }
        public string Rank { get; set; }
    }
}