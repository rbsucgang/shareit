﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExecPayroll_Web.Models
{

    public class LeaveParamchModel
    {
        public string NONT_VL { get; set; }
        public string TAXB_VL { get; set; }
        public string TAXB_SL { get; set; }
        public string NEWGROSS { get; set; }
    }



    public class LeavesModel
    {
        public string NEWGROSS { get; set; }
        public string NONT_VL { get; set; }
        public string NONT_AMT { get; set; }
        public string TAXB_VL { get; set; }
        public string TAXB_SL { get; set; }
        public string VLSL_TX { get; set; }
        public string TAXB_AMT { get; set; }
        
        //public decimal NEWGROSS { get; set; }
        //public double NONT_VL { get; set; }
        //public double NONT_AMT { get; set; }
        //public double TAXB_VL { get; set; }
        //public double TAXB_SL { get; set; }
        //public double VLSL_TX { get; set; }
        //public double TAXB_AMT { get; set; }

    }
}



