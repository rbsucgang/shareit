﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExecPayroll_Web.Generic;


namespace ExecPayroll_Web.Model
{
    public class FilterParamModel
    {
        public string par1 { get; set; }
        public int par2 { get; set; }
        public Enums.UserLevel UserLevel { get; set; }
    }


    // ArchiveParamModel date created: 08/23/2017 - ruel
    public class ArchiveParamModel
    {
        public string ARCHIVETABLE { get; set; }
        public int ISTAGVP { get; set; }
        public string SEARCHHINT { get; set; }
        public String UserLevel { get; set; }

        public bool ExportIncludeCurGross { get; set; }
        public bool ExportIncludeNewGross { get; set; }

        public int Other3 { get; set; }
        public int Other2 { get; set; }
        public int Other { get; set; }
        public int ESL { get; set; }
        public int Inc { get; set; }

        public int CG { get; set; }
        public int NOD { get; set; }
        public int NLD { get; set; }
        public int NBD { get; set; }
        public int ZOA { get; set; }
        public int ZLA { get; set; }
        public int ZBA { get; set; }
        public int NS { get; set; }
        public int OS { get; set; }
        public int ZNB { get; set; }
        public int ZNG { get; set; }

        public int ResM { get; set; }
        public int HM { get; set; }
        public int ZOB { get; set; }
        public int ZOG { get; set; }
        public int Subsidiary { get; set; }
        public int Recom { get; set; }

        public int RM { get; set; }
        public int Rank { get; set; }

        public int SearchKey { get; set; }
    }


    public class FilterQryModel
    {
        public String UserLevel { get; set; }

        public bool ExportIncludeCurGross { get; set; }
        public bool ExportIncludeNewGross { get; set; }

        public int Other3 { get; set; }
        public int Other2 { get; set; }
        public int Other { get; set; }
        public int ESL { get; set; }
        public int Inc { get; set; }

        public int CG { get; set; }
        public int NOD { get; set; }
        public int NLD { get; set; }
        public int NBD { get; set; }
        public int ZOA { get; set; }
        public int ZLA { get; set; }
        public int ZBA { get; set; }
        public int NS { get; set; }
        public int OS { get; set; }
        public int ZNB { get; set; }
        public int ZNG { get; set; }

        public int ResM { get; set; }
        public int HM { get; set; }
        public int ZOB { get; set; }
        public int ZOG { get; set; }
        public int Subsidiary { get; set; }
        public int Recom { get; set; }

        public int RM { get; set; }
        public int Rank { get; set; }

        public int SearchKey { get; set; }

        public int PageSize { get; set; }

        public int PageIndex { get; set; }

        public string InstanceGuid { get; set; }

        public int SearchEventOrigin { get; set; }
        //public string SearchValue { get; set; }
    }

    public class FilterModel 
    {
        public int Key { get; set; }
        public string Value { get; set; }
    }
}
