﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace app.Models
{
   public class Premium
    {
        // Premium
        public double PGROSSBASIS { get; set; }
        public double LEGALHRS { get; set; }
        public double SPECIALHRS { get; set; }
        public double LEGALRESTHRS { get; set; }
        public double SPECIALRESTHRS { get; set; }
        public double LEGALAMT { get; set; }
        public double SPECIALAMT { get; set; }
        public double LEGALRESTAMT { get; set; }
        public double SPECIALRESTAMT { get; set; }
        public double TOTLSAMT { get; set; }

        public List<Premium> lstPremium { get; set; }
        //Public Property lstPremium As List(Of Premium) = New List(Of Premium)
    }
}
