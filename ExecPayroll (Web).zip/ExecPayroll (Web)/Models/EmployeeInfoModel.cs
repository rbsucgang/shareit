﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ExecPayroll_Web.Generic; 

namespace ExecPayroll_Web.Models
{
    
    public class EmployeeSearchModel
    {
        public Enums.EmployeeSearchKey SearchKey { get; set; }
        public string SearchHint { get; set; }
        public int PageSize { get; set; }
        public int PageIndex { get; set; }
        public Guid InstanceGUID { get; set; }
        public Enums.EmployeeSearchEventOrigin SearchEventOrigin { get; set; }
        public Enums.UserLevel UserLevel { get; set; }
    }
    public class InfoModel
    {
        public Enums.ScalarType ScalarType { get; set; }
        public string ImportType { get; set; }
        public string  EmpNo { get; set; }
        public string UserRole { get; set; }
        public string SGVNo { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string Position { get; set; }
        public string PositionDesc { get; set; }
        public string NewPosition { get; set; }
        public string NewPositionDesc { get; set; }
        public string Recommendation { get; set; }
        public string DateHired { get; set; }
        public string DateResigned { get; set; }
        public string Institution { get; set; }
        public string InstitutionDesc { get; set; }
        public string Unit { get; set; }
        public string SubUnit { get; set; }
        public string Institution2 { get; set; }
        public string Institution2Desc { get; set; }
        public string Unit2 { get; set; }
        public string TagVP { get; set; }
        public string TagVPDate { get; set; }
        public int PageNo { get; set; }
        public int PageSize { get; set; }
    }
    
    public class EmployeeDetails
    {
        public InfoModel Info { get; set; }
        public BonusModel Bonus { get; set; }
        public RecommendationModel Recommendation { get; set; }
        public CurrentSalaryModel CurrentSalary { get; set; }
        public NewSalaryModel NewSalary { get; set; }
        public IncreaseModel Increase { get; set; }
        public MemoOnlyModel MemoOnly { get; set; }
        public LeavesModel Leaves { get; set; }
        public PremiumModel Premium { get; set; }
    }
}