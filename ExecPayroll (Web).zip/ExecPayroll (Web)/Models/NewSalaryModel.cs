﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace ExecPayroll_Web.Models
{
    public class NewSalaryModel
    {
        public decimal NewGross { get; set; }
        public decimal NewBasic { get; set; }
        public decimal NewRep { get; set; }
        public decimal NewTrav { get; set; }
        public decimal NewPa { get; set; }
        public decimal NewPacnt { get; set; }
        public bool NewDitag { get; set; }
        public decimal NewDiamt { get; set; }
        public decimal NewCreditRatio { get; set; }
        public bool NewDiforce { get; set; }
        public bool NewAlteredBasic { get; set; }
        public string NewRule { get; set; }
        public decimal NewOrigIncAmount { get; set; }
    }
}