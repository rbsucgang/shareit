﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace ExecPayroll_Web.Models
{
    public class CurrentSalaryModel
    {
        public decimal CurGross { get; set; }
        public decimal CurBasic { get; set; }
        public decimal CurRep { get; set; }
        public decimal CurTrav { get; set; }
        public decimal CurPa { get; set; }
        public decimal CurPacnt { get; set; }
        public bool CurDitag { get; set; }
        public decimal CurDiamt { get; set; }
        public decimal CurCreditRatio { get; set; }
        public bool CurDiforce { get; set; }
        public bool CurAlteredBasic { get; set; }
        public string CurRule { get; set; }
        public decimal CurOrigIncAmount { get; set; }
    }
}