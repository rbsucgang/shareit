﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecPayroll_Web.Models
{
    public class DifferentialModel
    {
        public decimal DiffGross { get; set; }
        public decimal DiffBasic { get; set; }
        public decimal DiffRA { get; set; }
        public decimal DiffTA { get; set; }
        public decimal DdiffPA { get; set; }
        public decimal MidGross { get; set; }
        public decimal MidBasic { get; set; }
        public decimal MidRA { get; set; }
        public decimal MidTA { get; set; }
        public decimal MidPA { get; set; }
    }
}