﻿using System;

namespace ExecPayroll_Web.Models
{
    public class ParametersInfoModel
    {
        public string ParamID { get; set; }
        public string ParamGroup { get; set; }
        public string KeyName { get; set; }
        public string Value { get; set; }
        public string SequenceNo { get; set; }
        public string EffDateFrom { get; set; }
        public string EffDateTo { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedIP { get; set; }
    }

    public class ParametersListModel
    {
        public string ParamID { get; set; }
        public string ParamGroup { get; set; }
        public string KeyName { get; set; }
        public string Value { get; set; }
        public string SequenceNo { get; set; }
        public string EffDateFrom { get; set; }
        public string EffDateTo { get; set; }
    }
}
