﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace ExecPayroll_Web.Models
{
    public class PfposiModel
    {
        public string Pos { get; set; }
        public string Desc { get; set; }
        public string Rank { get; set; }
        public int Grp { get; set; }
        public decimal Diamt { get; set; }
        public int Perannumcount { get; set; }
        public decimal CreditRatio { get; set; }        
        
    }
}