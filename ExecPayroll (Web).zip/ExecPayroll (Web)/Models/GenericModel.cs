﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecPayroll_Web.Models
{
    public class GenericModel
    {
        public string Key { get; set; }
        public string Value { get; set; }
        public int Idx { get; set; }
        public int FilteredID { get; set; }
        public string Value2 { get; set; }
    }
}