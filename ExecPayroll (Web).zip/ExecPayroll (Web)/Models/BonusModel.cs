﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecPayroll_Web.Models
{
    public class BonusModel
    {
        public string EmpNo { get; set; }
        public string NoOfMonths { get; set; }
        public string NoOfDays { get; set; }
        public string CutInLenMonth { get; set; }
        public string CutInLenDays { get; set; }
        public string ResultGross { get; set; }
        public string ResultBasic { get; set; }
        public string ResultRRA { get; set; }
        public string ResultTA { get; set; }
        public string BonusGross { get; set; }
        public string BonusBasic { get; set; }
        public string BonusRRA { get; set; }
        public string BonusTA { get; set; }
        public string CCardAmount { get; set; }
        public string CorpCard { get; set; }
        public string ForceCCard { get; set; }
        public string ForceBasic { get; set; }

    }
}