﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace ExecPayroll_Web.Models
{
    public class MemoOnlyModel
    {
        public String MORule { get; set; }
        //public Decimal MOCurGross { get; set; }
        //public Decimal MOCurBasic {get; set;}
        //public Decimal MOCurRep {get; set;}
        //public Decimal MOCurTrav {get; set;} 
        //public Decimal MOCurPA {get; set;} 
        //public Decimal MOCurDiamt {get; set;} 
        //public Boolean MOCurDitag {get; set;} 
        //public Boolean MOCurDiforce {get; set;} 
        //public Boolean MOCurAlteredBasic {get; set;} 
        //public Decimal MONewGross {get; set;} 
        //public Decimal MONewBasic {get; set;} 
        //public Decimal MONewRep {get; set;} 
        //public Decimal MONewTrav {get; set;} 
        //public Decimal MONewPA {get; set;} 
        //public Decimal MONewDiamt {get; set;} 
        //public Boolean MONewDitag {get; set;} 
        //public Boolean MONewDiforce {get; set;} 
        //public Boolean MONewAlteredBasic {get; set;} 
        //public Decimal MOCurIncAmt { get; set; }
        //public Decimal MOCurPct { get; set; }
        //public Decimal MOCurConfAmt { get; set; }
        //public Decimal MOIncAmt { get; set; }
        //public Decimal MOPCT { get; set; }
        //public Decimal MOConfAmt { get; set; }
        public Boolean IsMemo { get; set; }
        public String MOType { get; set; }
        public int MOOrder { get; set; }
        public int Order1 { get; set; }
        public string Order2 { get; set; }
        public int Order3 { get; set; }
        public string RegionCode { get; set; }
        public decimal CutMos2 { get; set; }
        public decimal CutDays2 { get; set; }
        public CurrentSalaryMemoModel CurrentSalaryMemo { get; set; }
        public NewSalaryMemoModel NewSalaryMemo { get; set; }
        public IncreaseMemoModel IncreaseMemo { get; set; }
    }

    public class CurrentSalaryMemoModel
    {
        public Decimal MOCurGross { get; set; }
        public Decimal MOCurBasic { get; set; }
        public Decimal MOCurRep { get; set; }
        public Decimal MOCurTrav { get; set; }
        public Decimal MOCurPA { get; set; }
        public Decimal MOCurDiamt { get; set; }
        public Boolean MOCurDitag { get; set; }
        public Boolean MOCurDiforce { get; set; }
        public Boolean MOCurAlteredBasic { get; set; }
    }

    public class NewSalaryMemoModel
    {
        public Decimal MONewGross { get; set; }
        public Decimal MONewBasic { get; set; }
        public Decimal MONewRep { get; set; }
        public Decimal MONewTrav { get; set; }
        public Decimal MONewPA { get; set; }
        public Decimal MONewDiamt { get; set; }
        public Boolean MONewDitag { get; set; }
        public Boolean MONewDiforce { get; set; }
        public Boolean MONewAlteredBasic { get; set; }
    }

    public class IncreaseMemoModel
    {
        public Decimal MOCurIncAmt { get; set; }
        public Decimal MOCurPct { get; set; }
        public Decimal MOCurConfAmt { get; set; }
        public Decimal MOIncAmt { get; set; }
        public Decimal MOPCT { get; set; }
        public Decimal MOConfAmt { get; set; }
    }
}