﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExecPayroll_Web.Models
{

    public class PremiumParamModel
    {
        public string LEGALHRS { get; set; }
        public string SPECIALHRS { get; set; }
        public string LEGALRESTHRS { get; set; }
        public string SPECIALRESTHRS { get; set; }
        public string PGROSSBASIS { get; set; }
    }


    public class PremiumModel
    {
        // Premium
        public string PGROSSBASIS { get; set; }
        public string LEGALHRS { get; set; }
        public string SPECIALHRS { get; set; }
        public string LEGALRESTHRS { get; set; }
        public string SPECIALRESTHRS { get; set; }
        public string LEGALAMT { get; set; }
        public string SPECIALAMT { get; set; }
        public string LEGALRESTAMT { get; set; }
        public string SPECIALRESTAMT { get; set; }
        public string TOTLSAMT { get; set; }

        //public double PGROSSBASIS { get; set; }
        //public double LEGALHRS { get; set; }
        //public double SPECIALHRS { get; set; }
        //public double LEGALRESTHRS { get; set; }
        //public double SPECIALRESTHRS { get; set; }
        //public double LEGALAMT { get; set; }
        //public double SPECIALAMT { get; set; }
        //public double LEGALRESTAMT { get; set; }
        //public double SPECIALRESTAMT { get; set; }
        //public double TOTLSAMT { get; set; }

        public List<PremiumModel> lstPremium { get; set; }
        //Public Property lstPremium As List(Of Premium) = New List(Of Premium)
    }
}
