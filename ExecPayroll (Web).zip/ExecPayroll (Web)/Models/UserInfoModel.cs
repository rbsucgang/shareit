﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace ExecPayroll_Web.Models
{
    public class UserInfoModel
    {
        public string UserID { get; set; }
        public Generic.Enums.UserLevel UserLevel { get; set; }
    }
}