﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace ExecPayroll_Web.Models
{
    public class IncreaseModel
    {        
        public decimal NewIncAmount { get; set; }
        public decimal NewIncPct { get; set; }
        public decimal NewIncConfAmt { get; set; }
        public decimal CurIncAmount { get; set; }
        public decimal CurPct { get; set; }
        public decimal CurConfAmt { get; set; }
        public decimal IncGross { get; set; }
        public decimal IncBasic { get; set; }
        public decimal IncRA { get; set; }
        public decimal IncTA { get; set; }
        public decimal IncPA { get; set; }
        public decimal IncDiamt { get; set; }
        public bool IncDitag { get; set; }
        public bool IncDiforce { get; set; }
        public bool IncAlteredBasic { get; set; }

    }
}