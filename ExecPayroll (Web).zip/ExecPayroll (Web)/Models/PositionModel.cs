﻿using System;

namespace ExecPayroll_Web.Models
{
    public class PositionInfoModel
    {
        public string Position { get; set; }
        public string Description { get; set; }
        public string Rank { get; set; }
        public string Group { get; set; }
        public string DiAmount { get; set; }
        public string PerAnnumCount { get; set; }
        public string CreditRatio { get; set; }
        public DateTime UpdatedDate { get; set; }
        public int UpdatedBy { get; set; }             
        public string UpdatedIP { get; set; }		    
    }


    public class PositionListModel
    {
        public string Position { get; set; }
        public string Description { get; set; }
        public string DiAmount { get; set; }
        public string PerAnnumCount { get; set; }
        public string CreditRatio { get; set; }
    }

}


