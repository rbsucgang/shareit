﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecPayroll_Web.Models
{
    public class EmployeeDynamicModel
    {
        public RecommendationModel Recommendation { get; set; }
        public CurrentSalaryModel CurrentSalary { get; set; }
        public NewSalaryModel NewSalary { get; set; }
        public IncreaseModel Increase { get; set; }
        public MemoOnlyModel MemoOnly { get; set; }
        public InfoModel EmployeeInfo { get; set; }
        public UserInfoModel UserInfo { get; set; }
    }
}
