﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace app.Models
{
    public class Leaves
    {

        // Leave
        public decimal NEWGROSS { get; set; }
        public double NONT_VL { get; set; }
        public double NONT_AMT { get; set; }
        public double TAXB_VL { get; set; }
        public double TAXB_SL { get; set; }
        public double VLSL_TX { get; set; }
        public double TAXB_AMTy { get; set; }

    }
}



