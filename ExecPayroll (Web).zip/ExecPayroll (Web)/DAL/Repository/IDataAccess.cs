﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExecPayroll_Web.DAL;


namespace ExecPayroll_Web.DAL.Repository
{
    interface IDataAccess
    {
        void StoredProcParameter(string sParamName, object sParamValue);
        DataTable ExecuteStoredProc(string StoredProcName);
        int ExecuteNonQuery(string StoredProcName);
    }
}
