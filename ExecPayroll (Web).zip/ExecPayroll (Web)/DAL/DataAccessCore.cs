﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace ExecPayroll_Web.DAL
{
    public class DataAccessCore : IDisposable
    {
        public DataAccessCore() { }

        private static string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ExecPayroll.ConnStr"].ToString();

        private List<MySqlParameter> _paramlist = new List<MySqlParameter>();

        public void StoredProcParameter(string sParamName, object sParamValue)
        {
            MySqlParameter _param = new MySqlParameter();
            _param.ParameterName = sParamName;
            _param.Value = sParamValue;
            _paramlist.Add(_param);
            var _type = sParamValue.GetType();
            Console.WriteLine(_type);
        }


        public DataSet ExecuteStoredProcDs(string StoredProcName)
        {
            DataSet ds = new DataSet();
            using (MySqlConnection con = new MySqlConnection(ConnectionString))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = StoredProcName;

                    if (_paramlist != null)
                    {
                        if (_paramlist.Count >= 0)
                        {
                            for (int Cnt = 0; Cnt <= _paramlist.Count - 1; Cnt++)
                            {
                                cmd.Parameters.AddWithValue(_paramlist[Cnt].ParameterName, _paramlist[Cnt].Value);
                            }
                            _paramlist.Clear();
                        }
                    }
                    using (MySqlDataAdapter sqlDA = new MySqlDataAdapter(cmd))
                    {
                        sqlDA.Fill(ds);
                    }

               }
            }
            return ds;
        }


        public DataTable ExecuteStoredProc(string StoredProcName)
        {
            DataTable dt = new DataTable();
            using (MySqlConnection con = new MySqlConnection(ConnectionString))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = StoredProcName;

                    if (_paramlist != null)
                    {
                        if (_paramlist.Count >= 0)
                        {
                            for (int Cnt = 0; Cnt <= _paramlist.Count - 1; Cnt++)
                            {
                                cmd.Parameters.AddWithValue(_paramlist[Cnt].ParameterName, _paramlist[Cnt].Value);
                            }
                            _paramlist.Clear();
                        }
                    }

                    //MySqlDataReader _rdr;
                    //_rdr = cmd.ExecuteReader();
                    //if(_rdr.HasRows == true)
                    //    dt.Load(_rdr);


                    using (MySqlDataAdapter sqlDA = new MySqlDataAdapter(cmd))
                    {
                        sqlDA.Fill(dt);
                    }



                }
            }
            return dt;
        }

        public int ExecuteNonQuery(string StoredProcName)
        {
            using (MySqlConnection con = new MySqlConnection(ConnectionString))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = StoredProcName;

                    if (_paramlist != null)
                    {
                        if (_paramlist.Count >= 0)
                        {
                            for (int Cnt = 0; Cnt <= _paramlist.Count - 1; Cnt++)
                            {
                                cmd.Parameters.AddWithValue(_paramlist[Cnt].ParameterName, _paramlist[Cnt].Value);
                            }
                            _paramlist.Clear();
                        }
                    }
                    return cmd.ExecuteNonQuery();
                }
            }
        }






        public string ExecuteScalar(string StoredProcName)
        {
            
            string result = string.Empty;
            using (MySqlConnection con = new MySqlConnection(ConnectionString))
            {
                con.Open();
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandTimeout = 0;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = StoredProcName;

                    if (_paramlist != null)
                    {
                        if (_paramlist.Count >= 0)
                        {
                            for (int Cnt = 0; Cnt <= _paramlist.Count - 1; Cnt++)
                            {
                                cmd.Parameters.AddWithValue(_paramlist[Cnt].ParameterName, _paramlist[Cnt].Value);
                            }
                            _paramlist.Clear();
                        }
                    }

                    result = (string)(cmd.ExecuteScalar());




                }
            }
            return result;
        }





        //public int CheckConn()
        //{
        //    int Status = 0;
        //    using (MySqlConnection con = new MySqlConnection(ConnectionString))
        //    {
        //        con.Open();
        //        if(con.State == ConnectionState.Open)
        //            Status = 1;
        //        else
        //            Status = 0;
        //    }
        //    return Status;
        //}

        #region Dispose
        private bool disposedValue = false; // To detect redundant calls
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                }
                disposedValue = true;
            }
        }

        ~DataAccessCore()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}