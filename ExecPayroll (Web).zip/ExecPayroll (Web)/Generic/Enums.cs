﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecPayroll_Web.Generic
{
    public class  Enums
    {

        public enum ResultValue
        {
            Success=0,            
            Failed=1
        }
        public enum EmployeeSearchKey
        {
            All = 0,
            Employeeno = 1,
            Lastname = 2,
            Firstname = 3,
            SGVNO = 4,
            XMLtoExport = 70,
            XMLtoArchive = 80,
            XMLtoArchiveFilter = 81,
            Xml = 99
        }

        public enum ScalarType
        {
            Park = 0,
            GetImportType = 1,
            GetBonusType = 2,
            GetLeaveType = 3,
            GetPremiumType = 4,
            GetTotalEmployee = 5,
            GetDiffCheckboxSwitch = 6
        }

        public enum UserLevel
        {
            None = 0,
            Level1 = 1,
            Level2 = 2,
            Level3 = 3
        }

        public enum EmployeeSearchEventOrigin
        {
            Park = 0,
            FilterTab = 1,
            SearchButton = 2
        }

        public enum ProcessType
        {
            Preprocess = 1,
            Increase = 2,
            Bonus = 3,
            Leaves = 4,
            Premium = 5,
            BonusPerInstitution = 6,
            LeavesPerInstitution = 7,
            PremiumPerInstitution = 8,
            MidyearDifferential = 9
        }

        public enum Bonustype
        {
            NONE = 0,
            MIDYEAR = 1,
            CHRISTMAS = 2,
            ONETIME = 3
        }
    }
}