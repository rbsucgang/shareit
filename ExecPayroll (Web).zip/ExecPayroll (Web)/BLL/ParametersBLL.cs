﻿using ExecPayroll_Web.DAL;
using ExecPayroll_Web.Models;
using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecPayroll_Web.BLL
{
    public class ParametersBLL
    { 
        public DataTable SearchParameters()
        {
            DataTable dt = new DataTable();
            List<ParametersListModel> _listmodel = new List<ParametersListModel>();
            try
            {

                using (DataAccessCore _core = new DataAccessCore())
                {
                    _core.StoredProcParameter("SEARCHKEY", 0);
                    _core.StoredProcParameter("SEARCHHINT", "");
                    dt = _core.ExecuteStoredProc("USP_TBLPARAMETER_READ");
                }
            }
            catch (Exception ex)
            { throw ex; }

            return dt;

        }

    }
}
