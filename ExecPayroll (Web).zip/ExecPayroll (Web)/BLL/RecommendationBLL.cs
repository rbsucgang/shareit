﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ExecPayroll_Web.DAL;
using ExecPayroll_Web.Models;
using System.Data;
using ExecPayroll_Web.Generic;

namespace ExecPayroll_Web.BLL
{
    public class RecommendationBLL : EmployeeDetails, IDisposable

    {

        public Enums.UserLevel Userlevel;

        
        public RecommendationBLL() { }


        public string GetNextRank(string thisRank, bool isDownward)
        {
            string newRank = string.Empty;
            using (DataAccessCore _core = new DataAccessCore())
            {
                _core.StoredProcParameter("xRank", thisRank);
                _core.StoredProcParameter("IsDown", isDownward);
                newRank= _core.ExecuteScalar("USP_TBLPFPOSI_GETNEXTRANK");
            }
                return newRank;
        }

        public PfposiModel GetPfposi( string pos)
        {
            PfposiModel _pfposi = new PfposiModel();
            DataTable _dt = new DataTable();
            using (DataAccessCore _core = new DataAccessCore())
            {
                _core.StoredProcParameter("pos", pos);
                _dt = _core.ExecuteStoredProc("USP_PFPOSI_READ");
                _pfposi = (from DataRow row in _dt.Rows select new PfposiModel() { Diamt = Convert.ToDecimal(row["Diamt"])}).FirstOrDefault();
            }
            return _pfposi;
        }

        public DataTable testExport()
        {
            DataTable dtReturn = new DataTable();
            
            using (DataAccessCore _core = new DataAccessCore())
            {
                _core.StoredProcParameter("xPosition", "");
                _core.StoredProcParameter("xStatus", "");
                _core.StoredProcParameter("xIsmemo", 0);
                _core.StoredProcParameter("xPreproctype", 2);
                dtReturn = _core.ExecuteStoredProc("USP_TBLEMPLOYEE_EXPORT");
            }
            return dtReturn;

           
        }

        public MemoOnlyModel CopyMIPtoMemo()
        {            
            int intReturn = 0;
            DataTable _dt = new DataTable();
            MemoOnlyModel _memo = new MemoOnlyModel();

            try
            {
                using (DataAccessCore _core = new DataAccessCore())
                {
                    _core.StoredProcParameter("xuserlevel", Userlevel.ToString());
                    _core.StoredProcParameter("xempno", Info.EmpNo);
                    intReturn = _core.ExecuteNonQuery("USP_PROCESSCOPYMIPTOMEMO");
                }
                if (intReturn > 0)
                {          
                    using (DataAccessCore _core = new DataAccessCore())
                    {
                        _core.StoredProcParameter("xempno", Info.EmpNo);
                        _dt = _core.ExecuteStoredProc("USP_TBLMEMOONLY_READ");
                        _memo = (from DataRow row in _dt.Rows
                                 select new MemoOnlyModel
                                 {
                                     CurrentSalaryMemo = new CurrentSalaryMemoModel()
                                     {
                                         MOCurGross = Convert.ToDecimal(row["MOCurGross"]),
                                         MOCurBasic = Convert.ToDecimal(row["MOCurBasic"]),
                                         MOCurRep = Convert.ToDecimal(row["MOCurRep"]),
                                         MOCurTrav = Convert.ToDecimal(row["MOCurTrav"]),
                                         MOCurPA = Convert.ToDecimal(row["MOCurPA"]),
                                         MOCurDiamt = Convert.ToDecimal(row["MOCurDiamt"]),
                                         MOCurDitag = Convert.ToBoolean(row["MOCurDitag"]),
                                         MOCurDiforce = Convert.ToBoolean(row["MOCurDiforce"]),
                                         MOCurAlteredBasic = Convert.ToBoolean(row["MOCurAlteredBasic"])                                         
                                     },
                                     NewSalaryMemo = new NewSalaryMemoModel()
                                     {                                        
                                         MONewGross = Convert.ToDecimal(row["MONewGross"]),
                                         MONewBasic = Convert.ToDecimal(row["MONewBasic"]),
                                         MONewRep = Convert.ToDecimal(row["MONewRep"]),
                                         MONewTrav = Convert.ToDecimal(row["MONewTrav"]),
                                         MONewPA = Convert.ToDecimal(row["MONewPA"]),
                                         MONewDiamt = Convert.ToDecimal(row["MONewDiamt"]),
                                         MONewDitag = Convert.ToBoolean(row["MONewDitag"]),
                                         MONewDiforce = Convert.ToBoolean(row["MONewDiforce"]),
                                         MONewAlteredBasic = Convert.ToBoolean(row["MONewAlteredBasic"]),                                         
                                     },
                                     IncreaseMemo = new IncreaseMemoModel()
                                     {                                         
                                         MOCurIncAmt = Convert.ToDecimal(row["MOCurIncAmt"]),
                                         MOCurPct = Convert.ToDecimal(row["MOCurPct"]),
                                         MOCurConfAmt = Convert.ToDecimal(row["MOCurConfAmt"]),
                                         MOIncAmt = Convert.ToDecimal(row["MOIncAmt"]),
                                         MOPCT = Convert.ToDecimal(row["MOPCT"]),
                                         MOConfAmt = Convert.ToDecimal(row["MOConfAmt"])
                                     }
                                     
                                 }).ToList().First();

                    }

                }
                               
            }
            catch (Exception ex){}

            return _memo;

        }

        public EmployeeDetails ResetNewSalaryIncrease(string Empno, string Action, bool isSalary)
        {
            EmployeeDetails _employee = new EmployeeDetails();
            NewSalaryModel _newsalary = new NewSalaryModel();
            IncreaseModel _increase = new IncreaseModel();
            
                        
            DataTable _dt = new DataTable();
            int intReturn = 0;
            try
            {
                using (DataAccessCore _core = new DataAccessCore())
                {
                    _core.StoredProcParameter("Empno", Empno);
                    _core.StoredProcParameter("Action", Action);
                    _core.StoredProcParameter("isSalary", isSalary);
                    intReturn = _core.ExecuteNonQuery("USP_RESETSALARYINCREASE");                                     
                }
                if (intReturn >= 0)
                {
                    using (DataAccessCore _core = new DataAccessCore())
                    {
                        _core.StoredProcParameter("xempno", Empno);
                        _dt = _core.ExecuteStoredProc("USP_RESETSALARYINCREASE_READ");
                    }
                }
                else
                { throw new Exception(string.Empty); }

                _newsalary = (from DataRow row in _dt.Rows
                              select new NewSalaryModel
                              {
                                  NewGross = Convert.ToDecimal(row["newgross"]),
                                  NewBasic = Convert.ToDecimal(row["newbasic"]),
                                  NewRep = Convert.ToDecimal(row["newrep"]),
                                  NewTrav = Convert.ToDecimal(row["newtrav"]),
                                  NewDiamt = Convert.ToDecimal(row["newdiamt"]),
                                  NewPa = Convert.ToDecimal(row["newpa"]),
                                  NewDiforce = Convert.ToBoolean(row["newdiforce"]),
                                  NewDitag = Convert.ToBoolean(row["newditag"]),
                                  NewAlteredBasic = Convert.ToBoolean(row["newalteredbasic"]),
                                  NewRule = row["newrule"].ToString()
                              }).ToList().First();
                _increase = (from DataRow row in _dt.Rows
                             select new IncreaseModel
                             {
                                 NewIncPct = Convert.ToDecimal(row["pct"]),
                                 NewIncAmount = Convert.ToDecimal(row["incamt"]),
                                 NewIncConfAmt = Convert.ToDecimal(row["CONFAMT"])
                             }).ToList().First();

                _employee.NewSalary = _newsalary;
                _employee.Increase = _increase;
                                
            }
            catch (Exception ex)
            {}



            return _employee;
        }

        


        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~RecommendationBLL() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}