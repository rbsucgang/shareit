﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ExecPayroll_Web.DAL;
using ExecPayroll_Web.DAL.Repository;
using ExecPayroll_Web.Models;
using ExecPayroll_Web.Model;
using System.Data;



namespace ExecPayroll_Web.BLL
{
    public class FilterBLL
    {


        public DataTable FilterEmployeeList(FilterQryModel SearchModel)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessCore _core = new DataAccessCore())
                {

                    _core.StoredProcParameter("UserLevel", SearchModel.UserLevel);
                    _core.StoredProcParameter("ExportIncludeCurGross", SearchModel.ExportIncludeCurGross);
                    _core.StoredProcParameter("ExportIncludeNewGross", SearchModel.ExportIncludeNewGross);
                    _core.StoredProcParameter("Other3", SearchModel.Other3);
                    _core.StoredProcParameter("Other2", SearchModel.Other2);
                    _core.StoredProcParameter("Other", SearchModel.Other);
                    _core.StoredProcParameter("ESL", SearchModel.ESL);

                    _core.StoredProcParameter("INC", SearchModel.Inc);
                    _core.StoredProcParameter("CG", SearchModel.CG);
                    _core.StoredProcParameter("NOD", SearchModel.NOD);
                    _core.StoredProcParameter("NLD", SearchModel.NLD);
                    _core.StoredProcParameter("NBD", SearchModel.NBD);
                    _core.StoredProcParameter("ZOA", SearchModel.ZOA);
                    _core.StoredProcParameter("ZLA", SearchModel.ZLA);
                    _core.StoredProcParameter("ZBA", SearchModel.ZBA);
                    _core.StoredProcParameter("NS", SearchModel.NS);
                    _core.StoredProcParameter("OS", SearchModel.OS);
                    _core.StoredProcParameter("ZNB", SearchModel.ZNB);

                    _core.StoredProcParameter("ZNG", SearchModel.ZNG);
                    _core.StoredProcParameter("ResM", SearchModel.ResM);
                    _core.StoredProcParameter("HM", SearchModel.HM);
                    _core.StoredProcParameter("ZOB", SearchModel.ZOB);
                    _core.StoredProcParameter("ZOG", SearchModel.ZOG);
                    _core.StoredProcParameter("Subsidiary", SearchModel.Subsidiary);
                    _core.StoredProcParameter("Recom", SearchModel.Recom);
                    _core.StoredProcParameter("RM", SearchModel.RM);
                    _core.StoredProcParameter("Rank", SearchModel.Rank);

                    dt = _core.ExecuteStoredProc("USP_TBLEMPLOYEE_READ_v2");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }



        //archive

        //ARCHIVETABLE VARCHAR(30), ISTAGVP TINYINT, SEARCHHINT VARCHAR(8000), SEARCHKEY INTEGER
        public DataSet GenerateArchive(ArchiveParamModel SearchModel)
        {
            DataSet ds = new DataSet();
            try
            {

                using (DataAccessCore _core = new DataAccessCore())
                {

                    _core.StoredProcParameter("ARCHIVETABLE", SearchModel.ARCHIVETABLE);
                    _core.StoredProcParameter("ISTAGVP", SearchModel.ISTAGVP);
                    _core.StoredProcParameter("SEARCHHINT", SearchModel.SEARCHHINT);
                    _core.StoredProcParameter("UserLevel", SearchModel.UserLevel);
                    _core.StoredProcParameter("ExportIncludeCurGross", SearchModel.ExportIncludeCurGross);
                    _core.StoredProcParameter("ExportIncludeNewGross", SearchModel.ExportIncludeNewGross);
                    _core.StoredProcParameter("Other3", SearchModel.Other3);
                    _core.StoredProcParameter("Other2", SearchModel.Other2);
                    _core.StoredProcParameter("Other", SearchModel.Other);
                    _core.StoredProcParameter("ESL", SearchModel.ESL);

                    _core.StoredProcParameter("INC", SearchModel.Inc);
                    _core.StoredProcParameter("CG", SearchModel.CG);
                    _core.StoredProcParameter("NOD", SearchModel.NOD);
                    _core.StoredProcParameter("NLD", SearchModel.NLD);
                    _core.StoredProcParameter("NBD", SearchModel.NBD);
                    _core.StoredProcParameter("ZOA", SearchModel.ZOA);
                    _core.StoredProcParameter("ZLA", SearchModel.ZLA);
                    _core.StoredProcParameter("ZBA", SearchModel.ZBA);
                    _core.StoredProcParameter("NS", SearchModel.NS);
                    _core.StoredProcParameter("OS", SearchModel.OS);
                    _core.StoredProcParameter("ZNB", SearchModel.ZNB);

                    _core.StoredProcParameter("ZNG", SearchModel.ZNG);
                    _core.StoredProcParameter("ResM", SearchModel.ResM);
                    _core.StoredProcParameter("HM", SearchModel.HM);
                    _core.StoredProcParameter("ZOB", SearchModel.ZOB);
                    _core.StoredProcParameter("ZOG", SearchModel.ZOG);
                    _core.StoredProcParameter("Subsidiary", SearchModel.Subsidiary);
                    _core.StoredProcParameter("Recom", SearchModel.Recom);
                    _core.StoredProcParameter("RM", SearchModel.RM);
                    _core.StoredProcParameter("Rank", SearchModel.Rank);
                    _core.StoredProcParameter("SEARCHKEY", SearchModel.SearchKey);

                    ds = _core.ExecuteStoredProcDs("USP_CREATEARCHIVE_v2");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ds;
        }

    }
}