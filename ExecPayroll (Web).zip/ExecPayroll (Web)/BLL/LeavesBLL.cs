﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using ExecPayroll_Web.DAL;
using ExecPayroll_Web.DAL.Repository;

using ExecPayroll_Web.Model;
using ExecPayroll_Web.Models;

namespace ExecPayroll_Web.BLL
{
    public class LeavesBLL :InfoModel

    {

        public LeavesBLL() { }
        public void GetEmployeeLeaves()
        {
            using (DataAccessCore _core = new DataAccessCore())
            {
                _core.StoredProcParameter("",  "");
                _core.ExecuteStoredProc("");
            }
            //USP_TBLEMPLOYEE_READ
        }

    }
}