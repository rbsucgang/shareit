﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ExecPayroll_Web.DAL;
using ExecPayroll_Web.DAL.Repository;
using ExecPayroll_Web.Models;
using ExecPayroll_Web.Model;
using System.Data;

namespace ExecPayroll_Web.BLL
{
    public class BusinessCore 
    {
        //public InfoModel GetEmployeeList()
        //{
        //    InfoModel _model = new InfoModel();
        //    try
        //    {
        //        using (DataAccessCore _core = new DataAccessCore())
        //        {
        //            _core.StoredProcParameter("SearchKey", "");
        //            _core.StoredProcParameter("SearchHint", "");
        //            _core.StoredProcParameter("PageSize", "");
        //            _core.StoredProcParameter("PageIndex", "");
        //            _core.StoredProcParameter("InstanceGUID", "");
        //            _core.StoredProcParameter("SearchEventOrigin", "");
        //            _core.StoredProcParameter("UserLevel", "");
        //            _core.ExecuteStoredProc("usp_TblEmployee_Read");
        //        }
        //    }
        //    catch (Exception ex)
        //    { throw ex; }
        //    return _model;
        //}

        public DataTable GetEmployeeList(EmployeeSearchModel SearchModel)
        {
            DataTable dt = new DataTable();
            InfoModel _model = new InfoModel();
            try
            {
                
                using (DataAccessCore _core = new DataAccessCore())
                {
                    //_core.StoredProcParameter("xSEARCHKEY", SearchModel.SearchKey);
                    //_core.StoredProcParameter("xSearchHint", SearchModel.SearchHint);
                    //_core.StoredProcParameter("xPageSize", SearchModel.PageSize);
                    //_core.StoredProcParameter("xPageIndex", SearchModel.PageIndex);
                    //_core.StoredProcParameter("xInstanceGUID", SearchModel.InstanceGUID);
                    //_core.StoredProcParameter("xSearchEventOrigin", SearchModel.SearchEventOrigin);
                    //_core.StoredProcParameter("xUserLevel", SearchModel.UserLevel);
                    //dt = _core.ExecuteStoredProc("usp_TblEmployee_Read");

                    _core.StoredProcParameter("SearchKey", SearchModel.SearchKey);
                    _core.StoredProcParameter("SearchHint", SearchModel.SearchHint);
                    _core.StoredProcParameter("UserLevel", SearchModel.UserLevel);
                    dt = _core.ExecuteStoredProc("usp_SearchEmployee");
                }
            }
            catch(Exception ex)
            { throw ex; }
            return dt;
        }
         
        public int UpdateEmployeeBonus(BonusModel Bonus)
        {
            int result = 0;
            InfoModel _model = new InfoModel();
            try
            {

                using (DataAccessCore _core = new DataAccessCore())
                {
                    _core.StoredProcParameter("EMPNO", Bonus.EmpNo);
                    _core.StoredProcParameter("RESGROSS", Convert.ToDecimal(Bonus.ResultGross));
                    _core.StoredProcParameter("RESBASIC", Convert.ToDecimal(Bonus.ResultBasic));
                    _core.StoredProcParameter("RESREP", Convert.ToDecimal(Bonus.ResultRRA));
                    _core.StoredProcParameter("RESTRAV", Convert.ToDecimal(Bonus.ResultTA));
                    _core.StoredProcParameter("BONUSGROSS", Convert.ToDecimal(Bonus.BonusGross));
                    _core.StoredProcParameter("BONUSBASIC", Convert.ToDecimal(Bonus.BonusBasic));
                    _core.StoredProcParameter("BONUSREP", Convert.ToDecimal(Bonus.BonusRRA));
                    _core.StoredProcParameter("BONUSTRAV", Convert.ToDecimal(Bonus.BonusTA));
                    result = _core.ExecuteNonQuery("usp_SaveBonus");
                }
            }
            catch (Exception ex)
            { throw ex; }
            return result;
        }
        //public int RunBonusProcess(ProcessType, )
        //{
        //    try
        //    {

        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return 0;
        //}


        //public DataTable GetRankList(FilterParamModel SearchModel)
        //{
        //    DataTable dt = new DataTable();
        //    FilterModel _model = new FilterModel();
        //    try
        //    {

        //        using (DataAccessCore _core = new DataAccessCore())
        //        {
        //            _core.StoredProcParameter("par1", SearchModel.par1);
        //            _core.StoredProcParameter("par2", SearchModel.par2);
        //            _core.StoredProcParameter("userlevel", SearchModel.UserLevel.ToString());
        //            dt = _core.ExecuteStoredProc("USP_GETCOLLECTION_GENERIC");
        //        }
        //    }
        //    catch (Exception ex)
        //    { throw ex; }
        //    return dt;
        //}

        public DataTable GetLeaveComputation(LeaveParamchModel paramModel)
        {
            DataTable dt = new DataTable();
            FilterModel _model = new FilterModel();
            try
            {

                using (DataAccessCore _core = new DataAccessCore())
                {
                    _core.StoredProcParameter("NONT_VL", Convert.ToDecimal(paramModel.NONT_VL));
                    _core.StoredProcParameter("TAXB_VL", Convert.ToDecimal(paramModel.TAXB_VL));
                    _core.StoredProcParameter("TAXB_SL", Convert.ToDecimal(paramModel.TAXB_SL));
                    _core.StoredProcParameter("NEWGROSS", Convert.ToDecimal(paramModel.NEWGROSS));

                    dt = _core.ExecuteStoredProc("USP_COMPUTELEAVESAMOUNT_PEREMPLOYEE");
                }
            }
            catch (Exception ex)
            { throw ex; }
            return dt;
        }


        public DataTable GetPremiumComputation(PremiumParamModel paramModel)
        {
            DataTable dt = new DataTable();
            FilterModel _model = new FilterModel();
            try
            {

                using (DataAccessCore _core = new DataAccessCore())
                {
                    _core.StoredProcParameter("LEGALHRS", Convert.ToDecimal(paramModel.LEGALHRS));
                    _core.StoredProcParameter("SPECIALHRS", Convert.ToDecimal(paramModel.SPECIALHRS));
                    _core.StoredProcParameter("LEGALRESTHRS", Convert.ToDecimal(paramModel.LEGALRESTHRS));
                    _core.StoredProcParameter("SPECIALRESTHRS", Convert.ToDecimal(paramModel.SPECIALRESTHRS));
                    _core.StoredProcParameter("PGROSSBASIS", Convert.ToDecimal(paramModel.PGROSSBASIS));

                    dt = _core.ExecuteStoredProc("USP_COMPUTEPREMIUMPAY");
                }
            }
            catch (Exception ex)
            { throw ex; }
            return dt;
        }




    }
}