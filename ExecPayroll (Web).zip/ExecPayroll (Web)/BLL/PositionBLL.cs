﻿using ExecPayroll_Web.DAL;
using ExecPayroll_Web.Models;
using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecPayroll_Web.BLL
{
    public class PositionBLL
    {
        ///public PositionListModel GetPositionAll(PositionInfoModel PositionModel )
        public List<PositionListModel> GetPositionAll()
        {
            DataTable dt = new DataTable();
            List<PositionListModel> _listmodel = new List<PositionListModel>();
            
            try
            {
                
                using (DataAccessCore _core = new DataAccessCore())
                {
                    _core.StoredProcParameter("USERLEVEL", "LEVEL1");
                    _core.StoredProcParameter("SEARCHKEY", "0");
                    _core.StoredProcParameter("SearchHint", "");
                    dt = _core.ExecuteStoredProc("USP_TBLPFPOSI_READ");

                    
                    if (dt.Rows.Count > 0)
                    {
                        for (int cnt = 0; cnt < dt.Rows.Count; cnt++)
                        {
                            PositionListModel _infoModel = new PositionListModel();
                            _infoModel.Position = dt.Rows[cnt]["POS"].ToString();
                            _infoModel.Description = dt.Rows[cnt]["DESC"].ToString();
                            _infoModel.DiAmount = dt.Rows[cnt]["DIAMT"].ToString();
                            _infoModel.PerAnnumCount = dt.Rows[cnt]["PERANNUMCOUNT"].ToString();
                            _infoModel.CreditRatio = dt.Rows[cnt]["CREDITRATIO"].ToString();
                            _listmodel.Add(_infoModel);
                        }
                    }
                }
            }
            catch (Exception ex)
            { throw ex; }

            return _listmodel;

        }

        public DataTable GetAllPositions()
        {
            DataTable dt = new DataTable();
            List<PositionListModel> _listmodel = new List<PositionListModel>();
            try
            {

                using (DataAccessCore _core = new DataAccessCore())
                {
                    _core.StoredProcParameter("USERLEVEL", "LEVEL1");
                    _core.StoredProcParameter("SEARCHKEY", "0");
                    _core.StoredProcParameter("SearchHint", "");
                    dt = _core.ExecuteStoredProc("USP_TBLPFPOSI_READ");                    
                }
            }
            catch (Exception ex)
            { throw ex; }

            return dt;
        }
        

        public int  SavePosition(PositionInfoModel PositionModel, int ModeID)
        {
            var intReturn = 0;
            PositionListModel _model = new PositionListModel();
            try
            {
                using (DataAccessCore _core = new DataAccessCore())
                {
                    _core.StoredProcParameter("_POS", PositionModel.Position);
                    _core.StoredProcParameter("DESCR", PositionModel.Description);
                    _core.StoredProcParameter("DIAMT", PositionModel.DiAmount);
                    _core.StoredProcParameter("PERANNUMCOUNT", PositionModel.PerAnnumCount);
                    _core.StoredProcParameter("CREDITRATIO", PositionModel.CreditRatio);
                    _core.StoredProcParameter("Mode", ModeID); //INSERT = 1, UPDATE = 2, DELETE = 3
                    _core.StoredProcParameter("UserID", "");
                    //_core.ExecuteNonQuery("USP_TBLPFPOSI_MAINTENANCE");
                    intReturn = 1;
                }
            }
            catch (Exception ex)
            {
                intReturn = -1;
                throw ex;
            }
            return intReturn;
        }

        public PositionInfoModel GetPosition(int ID)
        {
            PositionInfoModel _model = new PositionInfoModel();
            try
            {
                using (DataAccessCore _core = new DataAccessCore())
                {
                    _core.StoredProcParameter("USERLEVEL", "1");
                    _core.StoredProcParameter("SEARCHKEY", "0");
                    _core.StoredProcParameter("SearchHint", "");
                    _core.ExecuteNonQuery("USP_TBLPFPOSI_READ");
                }
            }
            catch (Exception ex)
            { throw ex; }
            return _model;
        }
    }
}