﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ExecPayroll_Web.DAL;
using ExecPayroll_Web.Models;
using System.Data;


namespace ExecPayroll_Web.BLL
{
    public class GenericBLL :IDisposable
    {

        public GenericBLL() { }

        public List<GenericModel> lstGenericCollection(string Param1, int Param2, Generic.Enums.UserLevel userlevel)
        {                                    
            List<GenericModel> _genericCollection = new List<GenericModel>();
            try
            {
               
                using (DataAccessCore _core = new DataAccessCore())
                {
                    _core.StoredProcParameter("@par1", Param1);
                    _core.StoredProcParameter("@par2", Param2);
                    _core.StoredProcParameter("@userlevel", userlevel.ToString());                    
                    _genericCollection = (from DataRow row in _core.ExecuteStoredProc("USP_GETCOLLECTION_GENERIC").Rows
                                            select new GenericModel{ Key = Convert.ToString(row["Key"]), Value = Convert.ToString(row["Value"]), FilteredID = Convert.ToInt16(row["filterid"]) }).ToList();
                    
                }
            }
            catch (Exception ex)
            { throw ex; }

            return _genericCollection;
        }

        

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~RecommendationBLL() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion

      
    }
}