﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ExecPayroll_Web.DAL;
using ExecPayroll_Web.Models;
using System.Data;
using ExecPayroll_Web.Generic;

namespace ExecPayroll_Web.BLL
{
    public class MemoOnlyBLL : EmployeeDetails, IDisposable
    {

        public Enums.UserLevel Userlevel;
        public MemoOnlyBLL() { }



        public MemoOnlyModel GenerateOrder()
        {
            MemoOnlyModel _memo = new MemoOnlyModel();
            DataTable _dt = new DataTable();
            using (DataAccessCore _core = new DataAccessCore())
            {
                _core.StoredProcParameter("xempno", Info.EmpNo);
                _core.StoredProcParameter("xrecomd", Recommendation.Recomd);
                _dt = _core.ExecuteStoredProc("USP_GENERATEORDERBYEMPNO2");
                _memo = (from DataRow row in _dt.Rows select new MemoOnlyModel() { Order1 = Convert.ToInt16(row["Order1"]), Order3 = Convert.ToInt16(row["Order3"]) }).FirstOrDefault();
            }
            return _memo;
        }

        public MemoOnlyModel Usememoforprinting()
        {

            MemoOnlyModel _memo = new MemoOnlyModel();
            DataTable _dt = new DataTable();
            int intResult = 0;
            try
            {
                using (DataAccessCore _core = new DataAccessCore())
                {                    
                    _core.StoredProcParameter("xempno", Info.EmpNo);                 
                    _core.StoredProcParameter("xismemo", MemoOnly.IsMemo );
                    intResult = _core.ExecuteNonQuery("USP_USEMEMOONLYFORPRINTING");
                }
                if (intResult != 0)
                {
                    using (DataAccessCore _core = new DataAccessCore())
                    {
                        _core.StoredProcParameter("xempno", Info.EmpNo);
                        _dt = _core.ExecuteStoredProc("USP_TBLMEMOONLY_READ");
                        _memo = (from DataRow row in _dt.Rows
                                 select new MemoOnlyModel
                                 {
                                     IsMemo = Convert.ToBoolean(row["ismemo"])
                                 }
                                ).ToList().FirstOrDefault();

                    }
                }
            }
            catch (Exception ex) { _memo.IsMemo = false; }
            return _memo;
        }



        public MemoOnlyModel ProcessMemo()
        {

            MemoOnlyModel _memo = new MemoOnlyModel();
            DataTable _dt = new DataTable();
            int intResult = 0;
            try
            {
                using (DataAccessCore _core = new DataAccessCore())
                {
                    _core.StoredProcParameter("xmotype", MemoOnly.MOType);
                    _core.StoredProcParameter("xempno", Info.EmpNo);
                    _core.StoredProcParameter("xuserlevel", Userlevel.ToString());
                    _core.StoredProcParameter("xmoorder", MemoOnly.MOOrder);
                    intResult = _core.ExecuteNonQuery("USP_PROCESSMEMO");
                }
                if (intResult != 0)
                {
                    using (DataAccessCore _core = new DataAccessCore())
                    {
                        _core.StoredProcParameter("xempno", Info.EmpNo);
                        _dt = _core.ExecuteStoredProc("USP_TBLMEMOONLY_READ");
                        _memo = (from DataRow row in _dt.Rows
                                 select new MemoOnlyModel
                                 {
                                     CurrentSalaryMemo = new CurrentSalaryMemoModel()
                                     {                                         
                                         MOCurGross = Convert.ToDecimal(row["MOCURGROSS"]),
                                         MOCurBasic = Convert.ToDecimal(row["MOCurBasic"]),
                                         MOCurRep = Convert.ToDecimal(row["MOCURREP"]),
                                         MOCurTrav = Convert.ToDecimal(row["MOCURTRAV"]),
                                         MOCurPA = Convert.ToDecimal(row["MOCURPA"]),
                                         MOCurDitag = Convert.ToBoolean(row["MOCURDITAG"]),
                                         MOCurDiamt = Convert.ToDecimal(row["MOCURDIAMT"]),
                                         MOCurDiforce = Convert.ToBoolean(row["MOCURDIFORCE"]),
                                         MOCurAlteredBasic = Convert.ToBoolean(row["MOCURALTEREDBASIC"])                                      
                                     },
                                     NewSalaryMemo = new NewSalaryMemoModel()
                                     {                                         
                                         MONewGross = Convert.ToDecimal(row["MONEWGROSS"]),
                                         MONewBasic = Convert.ToDecimal(row["MONEWBASIC"]),
                                         MONewRep = Convert.ToDecimal(row["MONEWREP"]),
                                         MONewTrav = Convert.ToDecimal(row["MONEWTRAV"]),
                                         MONewPA = Convert.ToDecimal(row["MONEWPA"]),
                                         MONewDitag = Convert.ToBoolean(row["MONEWDITAG"]),
                                         MONewDiamt = Convert.ToDecimal(row["MONEWDIAMT"]),
                                         MONewDiforce = Convert.ToBoolean(row["MONEWDIFORCE"]),
                                         MONewAlteredBasic = Convert.ToBoolean(row["MONEWALTEREDBASIC"])                                         
                                     },
                                     IncreaseMemo = new IncreaseMemoModel()
                                     {                                        
                                         MOPCT = Convert.ToDecimal(row["MOPCT"]),
                                         MOConfAmt = Convert.ToDecimal(row["MOCONFAMT"]),
                                         MOIncAmt = Convert.ToDecimal(row["MOINCAMT"]),
                                         MOCurPct = Convert.ToDecimal(row["MOCURPCT"]),
                                         MOCurConfAmt = Convert.ToDecimal(row["MOCURCONFAMT"]),
                                         MOCurIncAmt = Convert.ToDecimal(row["MOCURINCAMT"])
                                     }                                     
                                 }
                                ).ToList().FirstOrDefault();

                    }
                }
            }
            catch (Exception ex) { }
            return _memo;
        }




        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~MemoOnlyBLL() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}