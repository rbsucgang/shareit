﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ExecPayroll_Web.DAL;
using ExecPayroll_Web.DAL.Repository;
using ExecPayroll_Web.Models;
using ExecPayroll_Web.BLL;
using System.Data;
using ExecPayroll_Web.Generic;

namespace ExecPayroll_Web.Controllers
{
    public class ParametersController : Controller
    {
        // GET: Parameters
        public ActionResult Index()
        {
            return View();
        }


        [HttpGet]
        [Route("/Parameters/ListView")]
        public JsonResult ListView()
        {
            DataTable dt = new DataTable();
            List<ParametersListModel> _listmodel = new List<ParametersListModel>();
            ParametersInfoModel _infomodel = new ParametersInfoModel();
            ParametersBLL _core = new ParametersBLL();
            dt = _core.SearchParameters();
            if (dt.Rows.Count > 0)
            {
                for (int cnt = 0; cnt < dt.Rows.Count; cnt++)
                {
                    ParametersListModel _infoModel = new ParametersListModel();
                    _infoModel.ParamID = dt.Rows[cnt]["PARAMID"].ToString();
                    _infoModel.ParamGroup = dt.Rows[cnt]["PARAMGROUP"].ToString();
                    _infoModel.KeyName = dt.Rows[cnt]["KEYNAME"].ToString();
                    _infoModel.Value = dt.Rows[cnt]["VALUE"].ToString();
                    _infoModel.SequenceNo = dt.Rows[cnt]["IDX"].ToString();
                    _infoModel.EffDateFrom = dt.Rows[cnt]["EFFECTIVEDATESTART"].ToString();
                    _infoModel.EffDateTo = dt.Rows[cnt]["EFFECTIVEDATEEND"].ToString();
                    _listmodel.Add(_infoModel);
                }
            }
            return Json(_listmodel, JsonRequestBehavior.AllowGet);
        }

    }

}