﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ExecPayroll_Web.BLL;
using ExecPayroll_Web.Models;
using ExecPayroll_Web.Generic;

namespace ExecPayroll_Web.Controllers
{
    public class InformationController : Controller
    {
        // GET: Information
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public JsonResult ShowInformation()
        {
            DataTable dt = new DataTable();
            List<InfoModel> _listmodel = new List<InfoModel>();
            EmployeeSearchModel _searchmodel = new EmployeeSearchModel()
            {
                SearchKey = Enums.EmployeeSearchKey.Lastname,
                SearchHint = "",
                PageIndex = 1,
                PageSize = 50,
                SearchEventOrigin = Enums.EmployeeSearchEventOrigin.SearchButton,
                InstanceGUID = Guid.NewGuid(),
                UserLevel = Enums.UserLevel.Level1
            };
            BusinessCore _core = new BusinessCore();
            dt = _core.GetEmployeeList(_searchmodel);
            if (dt.Rows.Count > 0)
            {
                for (int cnt = 0; cnt <= dt.Rows.Count - 1; cnt++)
                {
                    InfoModel _model = new InfoModel();
                    _model.EmpNo = dt.Rows[cnt]["EmpNo"].ToString();
                    _model.LastName = dt.Rows[cnt]["LastName"].ToString();
                    _model.FirstName = dt.Rows[cnt]["FirstName"].ToString();
                    _model.MiddleName = dt.Rows[cnt]["MiddleName"].ToString();
                    _model.PageNo = 1;
                    _model.PageSize = 50;
                    _listmodel.Add(_model);
                }
            }
            return Json(_listmodel, JsonRequestBehavior.AllowGet);
        }

        //// GET: Information/Details/5
        //public ActionResult Details(int id)
        //{
        //    return View();
        //}

        //// GET: Information/Create
        //public ActionResult Create()
        //{
        //    return View();
        //}

        //// POST: Information/Create
        //[HttpPost]
        //public ActionResult Create(FormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add insert logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        //// GET: Information/Edit/5
        //public ActionResult Edit(int id)
        //{
        //    return View();
        //}

        //// POST: Information/Edit/5
        //[HttpPost]
        //public ActionResult Edit(int id, FormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add update logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        //// GET: Information/Delete/5
        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //// POST: Information/Delete/5
        //[HttpPost]
        //public ActionResult Delete(int id, FormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add delete logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
    }
}
