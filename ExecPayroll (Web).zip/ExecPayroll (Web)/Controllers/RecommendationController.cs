﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ExecPayroll_Web.BLL;
using ExecPayroll_Web.Models;
using ExecPayroll_Web.Generic;
using System.Data;
using ExecPayroll_Web;




namespace ExecPayroll_Web.Controllers
{
    public class RecommendationController :  Controller
    {
        

        // GET: Recommendation
        [HttpGet]
        public ActionResult ResetNewSalary( string empno)
        {
            NewSalaryModel _newsalary = new NewSalaryModel();
            using (RecommendationBLL _recom = new RecommendationBLL())
            {
                _newsalary = _recom.ResetNewSalaryIncrease(empno, "MODIFIED_DIFFERENTIAL", true).NewSalary;
            }

            return Json(_newsalary, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult ResetNewIncrease( string empno)
        {
            
            IncreaseModel _newincrease = new IncreaseModel();
            using (RecommendationBLL _recom = new RecommendationBLL())
            {
                _newincrease = _recom.ResetNewSalaryIncrease(empno, "MODIFIED_DIFFERENTIAL", false).Increase;
            }
            return Json(_newincrease, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public ActionResult RecomDropdownCollection(string Param)
        {
            List<GenericModel> _genericCollection = new List<GenericModel>();
            using (GenericBLL _generic = new GenericBLL())
            {
                _genericCollection = _generic.lstGenericCollection(Param, 2, Enums.UserLevel.Level1);
            }

            return Json(_genericCollection, JsonRequestBehavior.AllowGet);
        }
       

        [HttpGet]
        public ActionResult CopyMIPtoMemo(string empno)
        {            
            MemoOnlyModel _memo = new MemoOnlyModel();
            using (RecommendationBLL _recom = new RecommendationBLL() { Info= (new InfoModel() { EmpNo= empno }), Userlevel=Enums.UserLevel.Level1 })
            {                
                _memo = _recom.CopyMIPtoMemo();
            }
            return Json(_memo, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public ActionResult GetPfposi( string pos)
        {            
            PfposiModel pfposi = new PfposiModel();
            using (RecommendationBLL _recom = new RecommendationBLL())
            {

                pfposi = _recom.GetPfposi(pos);
            }
            return Json(pfposi, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GetNextRank(string thisRank, bool isDownward)
        {
            string newRank = string.Empty;
            using (RecommendationBLL _recom = new RecommendationBLL())
            {
                newRank =  _recom.GetNextRank( thisRank, isDownward);
            }
                return Json(newRank, JsonRequestBehavior.AllowGet);
        }


        


   
    }
}