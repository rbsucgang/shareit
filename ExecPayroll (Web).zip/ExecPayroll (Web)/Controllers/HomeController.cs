﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ExecPayroll_Web.BLL;
using ExecPayroll_Web.Models;
using ExecPayroll_Web.Generic;
using System.Data;

namespace ExecPayroll_Web.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            //DataTable dt = new DataTable();
            //InfoModel _model = new InfoModel();
            //List<InfoModel> _listmodel = new List<InfoModel>();
            //EmployeeSearchModel _searchmodel = new EmployeeSearchModel()
            //{
            //    SearchKey = Enums.EmployeeSearchKey.Lastname,
            //    SearchHint = "",
            //    PageIndex = 1,
            //    PageSize = 50,
            //    SearchEventOrigin = Enums.EmployeeSearchEventOrigin.SearchButton,
            //    InstanceGUID = Guid.NewGuid(),
            //    UserLevel = Enums.UserLevel.Level1
            //};
            //BusinessCore _core = new BusinessCore();
            //dt = _core.GetEmployeeList(_searchmodel);
            //if(dt.Rows.Count > 0)
            //{
            //    for(int cnt = 0; cnt <= dt.Rows.Count; cnt++)
            //    {
            //        _model.EmpNo = dt.Rows[cnt]["EmpNo"].ToString();
            //        _model.LastName = dt.Rows[cnt]["LastName"].ToString();
            //        _model.FirstName = dt.Rows[cnt]["FirstName"].ToString();
            //        _model.EmpNo = dt.Rows[cnt]["MiddleName"].ToString();
            //        _listmodel.Add(_model);
            //    }
            //}
            return View();
        }
        
    }
}