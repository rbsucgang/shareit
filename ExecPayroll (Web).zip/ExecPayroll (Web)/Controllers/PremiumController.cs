﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


using ExecPayroll_Web.Controllers;
using ExecPayroll_Web.Model;

using ExecPayroll_Web.BLL;
using ExecPayroll_Web.Models;
using ExecPayroll_Web.Generic;
using System.Data;


namespace ExecPayroll_Web.Controllers
{
    public class PremiumController : Controller
    {
        // GET: Premium
        public ActionResult PartialPremium()
        {
            return View();
        }

        [HttpGet]
        public JsonResult ComputePremium(string LEGALHRS, string SPECIALHRS, string LEGALRESTHRS, string SPECIALRESTHRS, string PGROSSBASIS)
        {
            PremiumModel obj = new PremiumModel();
            DataTable dt = new DataTable();
            BusinessCore _core = new BusinessCore();
            PremiumParamModel _param = new PremiumParamModel();
            _param.LEGALHRS = LEGALHRS;
            _param.SPECIALHRS = SPECIALHRS;
            _param.LEGALRESTHRS = LEGALRESTHRS;
            _param.SPECIALRESTHRS = SPECIALRESTHRS;
            _param.PGROSSBASIS = PGROSSBASIS;
            dt = _core.GetPremiumComputation(_param);

            obj.LEGALAMT = dt.Rows[0]["LEGALAMT"].ToString();
            obj.SPECIALAMT = dt.Rows[0]["SPECIALAMT"].ToString();
            obj.LEGALRESTAMT = dt.Rows[0]["LEGALRESTAMT"].ToString();

            obj.SPECIALRESTAMT = dt.Rows[0]["SPECIALRESTAMT"].ToString();
            obj.TOTLSAMT = dt.Rows[0]["TOTLSAMT"].ToString();
            return Json(obj, JsonRequestBehavior.AllowGet);
        }

    }
}