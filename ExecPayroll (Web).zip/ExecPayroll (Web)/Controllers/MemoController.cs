﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ExecPayroll_Web.BLL;
using ExecPayroll_Web.Models;
using ExecPayroll_Web.Generic;
using System.Data;
using ExecPayroll_Web;

namespace ExecPayroll_Web.Controllers
{
    public class MemoController : Controller
    {


        [HttpGet]
        public ActionResult Usememoforprinting(string empno, Boolean ismemo)
        {

            MemoOnlyModel _memo = new MemoOnlyModel();

            using (MemoOnlyBLL _memobll = new MemoOnlyBLL() { Info = new InfoModel() { EmpNo = empno }, MemoOnly = new MemoOnlyModel() { IsMemo = ismemo } })
            {
                _memo = _memobll.Usememoforprinting();
            }

            return Json(_memo, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public ActionResult ProcessMemo(string empno, string motype)
        {
            MemoOnlyModel _memo = new MemoOnlyModel();
            using (MemoOnlyBLL _recom = new MemoOnlyBLL() { MemoOnly = (new MemoOnlyModel() { MOType = motype, MOOrder = 1 }), Info = (new InfoModel() { EmpNo = empno }), Userlevel = Enums.UserLevel.Level1 })
            {
                _memo = _recom.ProcessMemo();
            }
            return Json(_memo, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GenerateOrder(string empno, string recomd)
        {
            MemoOnlyModel _memo = new MemoOnlyModel();
            using (MemoOnlyBLL _memobll = new MemoOnlyBLL() { Info = (new InfoModel() { EmpNo = empno }), Recommendation = (new RecommendationModel() { Recomd = recomd }) })
            {
                _memo = _memobll.GenerateOrder();
            }

            return Json(_memo, JsonRequestBehavior.AllowGet);
        }

    }
}