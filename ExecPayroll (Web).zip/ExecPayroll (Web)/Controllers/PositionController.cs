﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ExecPayroll_Web.DAL;
using ExecPayroll_Web.DAL.Repository;
using ExecPayroll_Web.Models;
using ExecPayroll_Web.BLL;
using System.Data;
using ExecPayroll_Web.Generic;

namespace ExecPayroll_Web.Controllers
{
    public class PositionController : Controller
    {
        // GET: Position
        public ActionResult Index()
        {
            return View();
        }

        // GET: Position/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        [HttpGet]
        [Route("/Position/ListView")]
        public JsonResult ListView()
        {
            DataTable dt = new DataTable();
            List<PositionListModel> _listmodel = new List<PositionListModel>();
            PositionInfoModel _infomodel = new PositionInfoModel();
            PositionBLL _core = new PositionBLL();
            dt = _core.GetAllPositions();
            if (dt.Rows.Count > 0)
            {
                for (int cnt = 0; cnt < dt.Rows.Count; cnt++)
                {
                    PositionListModel _infoModel = new PositionListModel();
                    _infoModel.Position = dt.Rows[cnt]["POS"].ToString();
                    _infoModel.Description = dt.Rows[cnt]["DESC"].ToString();
                    _infoModel.DiAmount = dt.Rows[cnt]["DIAMT"].ToString();
                    _infoModel.PerAnnumCount = dt.Rows[cnt]["PERANNUMCOUNT"].ToString();
                    _infoModel.CreditRatio = dt.Rows[cnt]["CREDITRATIO"].ToString();
                    _listmodel.Add(_infoModel);
                }
            }
            return Json(_listmodel, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        [Route("/Position/FilterView")]
        public JsonResult FilterView(string _searchType, string _searchString)
        {
            DataTable dt = new DataTable();
            List<PositionListModel> _listmodel = new List<PositionListModel>();
            PositionInfoModel _infomodel = new PositionInfoModel();
            PositionBLL _core = new PositionBLL();
            dt = _core.GetAllPositions();
            if (dt.Rows.Count > 0)
            {
                for (int cnt = 0; cnt < dt.Rows.Count; cnt++)
                {
                    string _tempCODE = "";
                    string _tempDESC = "";
                    bool blnRecTrue = false;
                    _tempCODE = dt.Rows[cnt]["POS"].ToString();
                    _tempDESC = dt.Rows[cnt]["DESC"].ToString();
                    if (((_searchType == "CODE") || (_searchType == "ALL")) && (_tempCODE.Contains(_searchString)))
                    {
                        blnRecTrue = true;
                    }
                    if (((_searchType == "DESC") || (_searchType == "ALL")) && (_tempDESC.Contains(_searchString)))
                    {
                        blnRecTrue = true;
                    }
                    if (blnRecTrue) {
                        PositionListModel _infoModel = new PositionListModel();
                        _infoModel.Position = dt.Rows[cnt]["POS"].ToString();
                        _infoModel.Description = dt.Rows[cnt]["DESC"].ToString();
                        _infoModel.DiAmount = dt.Rows[cnt]["DIAMT"].ToString();
                        _infoModel.PerAnnumCount = dt.Rows[cnt]["PERANNUMCOUNT"].ToString();
                        _infoModel.CreditRatio = dt.Rows[cnt]["CREDITRATIO"].ToString();
                        _listmodel.Add(_infoModel);
                    }                    
                }
            }
            return Json(_listmodel, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [Route("/Position/UpdatePosition")]
        public int UpdatePosition(PositionInfoModel data)
        {
            int intReturn = 0;            
            PositionInfoModel _infoModel = new PositionInfoModel()
            {
                Position = data.Position,
                Description = data.Description,
                DiAmount = data.DiAmount,
                PerAnnumCount = data.PerAnnumCount,
                CreditRatio = data.CreditRatio
            };

            PositionBLL _core = new PositionBLL();
            intReturn = _core.SavePosition(_infoModel, 2);
            
            return intReturn;
        }

        [HttpPost]
        [Route("/Position/CreatePosition")]
        public int CreatePosition(PositionInfoModel InfoModel)
        {
            int intReturn = 0;
            PositionInfoModel _infoModel = new PositionInfoModel()
            {
                Position = InfoModel.Position,
                Description = InfoModel.Description,
                DiAmount = InfoModel.DiAmount,
                PerAnnumCount = InfoModel.PerAnnumCount,
                CreditRatio = InfoModel.CreditRatio
            };

            PositionBLL _core = new PositionBLL();
            intReturn = _core.SavePosition(_infoModel, 1);

            return intReturn;
        }




        //// GET: Position/Create
        //public ActionResult Create()
        //{
        //    return View();
        //}

        //// POST: Position/Create
        //[HttpPost]
        //public ActionResult Create(FormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add insert logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        //// GET: Position/Edit/5
        //public ActionResult Edit(int id)
        //{

        //    PositionInfoModel _InfoModel = new PositionInfoModel();
        //    {

        //    };
        //    PositionBLL _core = new PositionBLL();
        //    _InfoModel = _core.GetPosition(id);
        //    return View();
        //}

        //// POST: Position/Edit/5
        //[HttpPost]
        //public ActionResult Edit(int id, FormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add update logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        //// GET: Position/Delete/5
        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //// POST: Position/Delete/5
        //[HttpPost]
        //public ActionResult Delete(int id, FormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add delete logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
    }
}
