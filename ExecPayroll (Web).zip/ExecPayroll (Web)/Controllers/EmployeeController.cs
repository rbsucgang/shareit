﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ExecPayroll_Web.BLL;
using ExecPayroll_Web.Models;
using ExecPayroll_Web.Generic;
using System.Data;

namespace ExecPayroll_Web.Controllers
{ 
    public class EmployeeController : Controller
    {
        // GET: Employee
        //[ActionName("EmployeeList")]
        public ActionResult Index()
        {

            return View();
        }

               
        public ActionResult Informatoin()
        {
            return View();
        }

        [HttpGet]
        [Route("/Employee/ShowEmployee")]
        public JsonResult ShowEmployee()
        {
            DataTable dt = new DataTable();
            List<InfoModel> _listmodel = new List<InfoModel>();
            EmployeeSearchModel _searchmodel = new EmployeeSearchModel()
            {
                SearchKey = Enums.EmployeeSearchKey.Employeeno,
                SearchHint = "",
                PageIndex = 1,
                PageSize = 50,
                SearchEventOrigin = Enums.EmployeeSearchEventOrigin.SearchButton,
                InstanceGUID = Guid.NewGuid(),
                UserLevel = Enums.UserLevel.Level1
            };
            BusinessCore _core = new BusinessCore();
            dt = _core.GetEmployeeList(_searchmodel);
            if (dt.Rows.Count > 0)
            {
                for (int cnt = 0; cnt <= dt.Rows.Count - 1; cnt++)
                {
                    InfoModel _model = new InfoModel();
                    _model.EmpNo = Convert.ToString(dt.Rows[cnt]["EmpNo"]);
                    _model.LastName = Convert.ToString(dt.Rows[cnt]["LastName"]);
                    _model.FirstName = Convert.ToString(dt.Rows[cnt]["FirstName"]);
                    _model.MiddleName = Convert.ToString(dt.Rows[cnt]["MiddleName"]);
                    //_model.SGVNo = dt.Rows[cnt]["SGVNo"].ToString();
                    //_model.Position = dt.Rows[cnt]["Pos"].ToString();
                    //_model.PositionDesc = dt.Rows[cnt]["PosDesc"].ToString();
                    if (dt.Rows[cnt]["DateHired"].ToString() != "")
                        _model.DateHired = Convert.ToString(Convert.ToDateTime(dt.Rows[cnt]["DateHired"]).ToString("MM/dd/yyyy"));
                    else
                        _model.DateHired = "";

                    if (dt.Rows[cnt]["DateResigned"].ToString() != "")
                        _model.DateResigned = Convert.ToString(Convert.ToDateTime(dt.Rows[cnt]["DateResigned"]).ToString("MM/dd/yyyy"));
                    else
                        _model.DateResigned = "";

                    _model.TagVP = Convert.ToString(dt.Rows[cnt]["TagVP"]);

                    if (dt.Rows[cnt]["TagVPDate"].ToString() != "")
                        _model.TagVPDate = Convert.ToString(Convert.ToDateTime(dt.Rows[cnt]["TagVPDate"]).ToString("MM/dd/yyyy"));
                    else
                        _model.TagVPDate = "";
                    
                    //BonusModel _modelBonus = new BonusModel();
                    //_modelBonus.NoOfMonths = dt.Rows[cnt]["DNoMos"].ToString();
                    //_modelBonus.NoOfDays = dt.Rows[cnt]["DNoDays"].ToString();

                    _model.PageNo = 1;
                    _model.PageSize = 50;
                    _listmodel.Add(_model);
                }
            }
            return Json(_listmodel, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        //[Route("/Employee/ShowEmployee")]
        public JsonResult ShowEmployeeList(string EmployeeNo, Enums.EmployeeSearchKey SearchKeyID)
        {
            DataTable dt = new DataTable();
            List<InfoModel> _listmodel = new List<InfoModel>();
            EmployeeSearchModel _searchmodel = new EmployeeSearchModel()
            {
                SearchKey = SearchKeyID,
                SearchHint = EmployeeNo,
                PageIndex = 1,
                PageSize = 50,
                SearchEventOrigin = Enums.EmployeeSearchEventOrigin.SearchButton,
                InstanceGUID = Guid.NewGuid(),
                UserLevel = Enums.UserLevel.Level1
            };
            BusinessCore _core = new BusinessCore();
            dt = _core.GetEmployeeList(_searchmodel);
            if (dt.Rows.Count > 0)
            {
                for (int cnt = 0; cnt <= dt.Rows.Count - 1; cnt++)
                {
                    InfoModel _model = new InfoModel();
                    _model.EmpNo = Convert.ToString(dt.Rows[cnt]["EmpNo"]);
                    _model.LastName = Convert.ToString(dt.Rows[cnt]["LastName"]);
                    _model.FirstName = Convert.ToString(dt.Rows[cnt]["FirstName"]);
                    _model.MiddleName = Convert.ToString(dt.Rows[cnt]["MiddleName"]);

                    if (dt.Rows[cnt]["DateHired"].ToString() != "")
                        _model.DateHired = Convert.ToString(Convert.ToDateTime(dt.Rows[cnt]["DateHired"]).ToString("MM/dd/yyyy"));
                    else
                        _model.DateHired = "";

                    if (dt.Rows[cnt]["DateResigned"].ToString() != "")
                        _model.DateResigned = Convert.ToString(Convert.ToDateTime(dt.Rows[cnt]["DateResigned"]).ToString("MM/dd/yyyy"));
                    else
                        _model.DateResigned = "";

                    _model.TagVP = Convert.ToString(dt.Rows[cnt]["TagVP"]);

                    if (dt.Rows[cnt]["TagVPDate"].ToString() != "")
                        _model.TagVPDate = Convert.ToString(Convert.ToDateTime(dt.Rows[cnt]["TagVPDate"]).ToString("MM/dd/yyyy"));
                    else
                        _model.TagVPDate = "";
                    
                    _model.PageNo = 1;
                    _model.PageSize = 50;
                    _listmodel.Add(_model);
                }
            }
            return Json(_listmodel, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetRankList()
        {
            List<GenericModel> _Generic = new List<GenericModel>();
            GenericBLL _List = new GenericBLL();
            _Generic = _List.lstGenericCollection("rank", 2, Enums.UserLevel.Level1);
            return Json(_Generic, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetPARSubList()
        {
            List<GenericModel> _Generic = new List<GenericModel>();
            GenericBLL _List = new GenericBLL();
            _Generic = _List.lstGenericCollection("institution", 2, Enums.UserLevel.Level1);
            return Json(_Generic, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetPayrollSubList()
        {
            List<GenericModel> _Generic = new List<GenericModel>();
            GenericBLL _List = new GenericBLL();
            _Generic = _List.lstGenericCollection("institution", 2, Enums.UserLevel.Level1);
            return Json(_Generic, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        //[Route("/Employee/ShowEmployeeInfo")]
        public JsonResult ShowEmployeeInfo(string EmployeeNo, Enums.EmployeeSearchKey SearchKeyID)
        {
            DataTable dt = new DataTable();
            InfoModel _Info = new InfoModel();
            BonusModel _Bonus = new BonusModel();
            LeavesModel _Leave = new LeavesModel();
            MemoOnlyModel _Memo = new MemoOnlyModel();
            PremiumModel _Premium = new PremiumModel();
            RecommendationModel _Recom = new RecommendationModel();
            CurrentSalaryModel _CurrentSalary = new CurrentSalaryModel();
            NewSalaryModel _NewSalary = new NewSalaryModel();
            IncreaseModel _Increase = new IncreaseModel();

            EmployeeDetails _Details = new EmployeeDetails();

            EmployeeSearchModel _searchmodel = new EmployeeSearchModel()
            {
                //SearchKey = Enums.EmployeeSearchKey.Employeeno,
                SearchKey = SearchKeyID,
                SearchHint = EmployeeNo,
                PageIndex = 1,
                PageSize = 50,
                SearchEventOrigin = Enums.EmployeeSearchEventOrigin.SearchButton,
                InstanceGUID = Guid.NewGuid(),
                UserLevel = Enums.UserLevel.Level1
            };
            BusinessCore _core = new BusinessCore();
            int cnt = 0;
            dt = _core.GetEmployeeList(_searchmodel);
            if (dt.Rows.Count > 0)
            {
                _Info.EmpNo = Convert.ToString(dt.Rows[cnt]["EmpNo"]);
                _Info.LastName = Convert.ToString(dt.Rows[cnt]["LastName"]);
                _Info.FirstName = Convert.ToString(dt.Rows[cnt]["FirstName"]);
                _Info.MiddleName = Convert.ToString(dt.Rows[cnt]["MiddleName"]);
                _Info.SGVNo = Convert.ToString(dt.Rows[cnt]["SGVNo"]);
                _Info.Position = Convert.ToString(dt.Rows[cnt]["Pos"]);
                _Info.PositionDesc = Convert.ToString(dt.Rows[cnt]["PosDesc"]);
                _Info.NewPosition = Convert.ToString(dt.Rows[cnt]["NewPos"]);
                _Info.Unit = Convert.ToString(dt.Rows[cnt]["Unit"]);
                _Info.Unit2 = Convert.ToString(dt.Rows[cnt]["Unit2"]);
                _Info.SubUnit = Convert.ToString(dt.Rows[cnt]["SUBUNIT"]);
                _Info.Institution = Convert.ToString(dt.Rows[cnt]["Institution"]);
                _Info.Institution2 = Convert.ToString(dt.Rows[cnt]["Institution2"]);


                if (dt.Rows[cnt]["DateHired"].ToString() == "")
                    _Info.DateHired = "";
                else
                    _Info.DateHired = Convert.ToString(Convert.ToDateTime(dt.Rows[cnt]["DateHired"]).ToString("MM/dd/yyyy"));

                if (dt.Rows[cnt]["DateResigned"].ToString() == "")
                    _Info.DateResigned = "";
                else
                    _Info.DateResigned = Convert.ToString(Convert.ToDateTime(dt.Rows[cnt]["DateResigned"]).ToString("MM/dd/yyyy"));

                _Info.TagVP = Convert.ToString(dt.Rows[cnt]["TagVP"]);
                if (dt.Rows[cnt]["DateResigned"].ToString() == "")
                    _Info.TagVPDate = "";
                else
                    _Info.TagVPDate = Convert.ToString(Convert.ToDateTime(dt.Rows[cnt]["TagVPDate"]).ToString("MM/dd/yyyy"));
                _Info.PageNo = 1;
                _Info.PageSize = 50;

                _Bonus.EmpNo = Convert.ToString(dt.Rows[cnt]["EmpNo"]);
                _Bonus.NoOfMonths = Convert.ToString(Convert.ToDecimal(dt.Rows[cnt]["DNoMos"]).ToString("#0.00"));
                _Bonus.NoOfDays = Convert.ToString(Convert.ToDecimal(dt.Rows[cnt]["DNoDays"]).ToString("#0.00"));
                _Bonus.CutInLenMonth = Convert.ToString(Convert.ToDecimal(dt.Rows[cnt]["CutMos"]).ToString("#0.00"));
                _Bonus.CutInLenDays = Convert.ToString(Convert.ToDecimal(dt.Rows[cnt]["CutDays"]).ToString("#0.00"));
                _Bonus.ResultGross = Convert.ToString(Convert.ToDecimal(dt.Rows[cnt]["RESGROSS"]).ToString("#,##0.00"));
                _Bonus.ResultBasic = Convert.ToString(Convert.ToDecimal(dt.Rows[cnt]["RESBASIC"]).ToString("#,##0.00"));
                _Bonus.ResultRRA = Convert.ToString(Convert.ToDecimal(dt.Rows[cnt]["RESREP"]).ToString("#,##0.00"));
                _Bonus.ResultTA = Convert.ToString(Convert.ToDecimal(dt.Rows[cnt]["RESTRAV"]).ToString("#,##0.00"));
                _Bonus.BonusGross = Convert.ToString(Convert.ToDecimal(dt.Rows[cnt]["BONUSGROSS"]).ToString("#,##0.00"));
                _Bonus.BonusBasic = Convert.ToString(Convert.ToDecimal(dt.Rows[cnt]["BONUSBASIC"]).ToString("#,##0.00"));
                _Bonus.BonusRRA = Convert.ToString(Convert.ToDecimal(dt.Rows[cnt]["BONUSREP"]).ToString("#,##0.00"));
                _Bonus.BonusTA = Convert.ToString(Convert.ToDecimal(dt.Rows[cnt]["BONUSTRAV"]).ToString("#,##0.00"));
                _Bonus.CCardAmount = Convert.ToString(Convert.ToDecimal(dt.Rows[cnt]["DIAMT"]).ToString("#,##0.00"));
                _Bonus.CorpCard = Convert.ToString(dt.Rows[cnt]["DITAG"]);
                _Bonus.ForceCCard = Convert.ToString(dt.Rows[cnt]["DIFORCE"]);
                _Bonus.ForceBasic = Convert.ToString(dt.Rows[cnt]["ALTEREDBASIC"]);

                _Leave.NEWGROSS = Convert.ToString(Convert.ToDecimal(dt.Rows[cnt]["NEWGROSS"]).ToString("#,##0.00"));
                _Leave.NONT_VL = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["NONT_VL"]).ToString("#,##0.00"));
                _Leave.NONT_AMT = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["NONT_AMT"]).ToString("#,##0.00"));
                _Leave.TAXB_VL = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["TAXB_VL"]).ToString("#,##0.00"));
                _Leave.TAXB_SL = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["TAXB_SL"]).ToString("#,##0.00"));
                _Leave.VLSL_TX = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["VLSL_TX"]).ToString("#,##0.00"));
                _Leave.TAXB_AMT = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["TAXB_AMT"]).ToString("#,##0.00"));

                //---

                _Memo.CurrentSalaryMemo = new CurrentSalaryMemoModel()
                {
                    MOCurGross = Convert.ToDecimal(dt.Rows[cnt]["MOCURGROSS"]),
                    MOCurBasic = Convert.ToDecimal(dt.Rows[cnt]["MOCURBASIC"]),
                    MOCurRep = Convert.ToDecimal(dt.Rows[cnt]["MOCURREP"]),
                    MOCurTrav = Convert.ToDecimal(dt.Rows[cnt]["MOCURTRAV"]),
                    MOCurPA = Convert.ToDecimal(dt.Rows[cnt]["MOCURPA"]),
                    MOCurDiamt = Convert.ToDecimal(dt.Rows[cnt]["MOCURDIAMT"]),
                    MOCurDitag = Convert.ToBoolean(dt.Rows[cnt]["MOCURDITAG"]),
                    MOCurDiforce = Convert.ToBoolean(dt.Rows[cnt]["MOCURDIFORCE"]),
                    MOCurAlteredBasic = Convert.ToBoolean(dt.Rows[cnt]["MOCURALTEREDBASIC"])
                };

                _Memo.NewSalaryMemo = new NewSalaryMemoModel()
                {
                    MONewGross = Convert.ToDecimal(dt.Rows[cnt]["MONEWGROSS"]),
                    MONewBasic = Convert.ToDecimal(dt.Rows[cnt]["MONEWBASIC"]),
                    MONewRep = Convert.ToDecimal(dt.Rows[cnt]["MONEWREP"]),
                    MONewTrav = Convert.ToDecimal(dt.Rows[cnt]["MONEWTRAV"]),
                    MONewPA = Convert.ToDecimal(dt.Rows[cnt]["MONEWPA"]),
                    MONewDiamt = Convert.ToDecimal(dt.Rows[cnt]["MONEWDIAMT"]),
                    MONewDitag = Convert.ToBoolean(dt.Rows[cnt]["MONEWDITAG"]),
                    MONewDiforce = Convert.ToBoolean(dt.Rows[cnt]["MONEWDIFORCE"]),
                    MONewAlteredBasic = Convert.ToBoolean(dt.Rows[cnt]["MONEWALTEREDBASIC"])
                };

                _Memo.IncreaseMemo = new IncreaseMemoModel()
                {
                    MOPCT = Convert.ToDecimal(dt.Rows[cnt]["MOPCT"]),
                    MOConfAmt = Convert.ToDecimal(dt.Rows[cnt]["MOCONFAMT"]),
                    MOIncAmt = Convert.ToDecimal(dt.Rows[cnt]["MOINCAMT"])
                };

                _Memo.IsMemo = Convert.ToBoolean(dt.Rows[cnt]["ISMEMO"]);
                _Memo.RegionCode = Convert.ToString(dt.Rows[cnt]["REGIONCODE"]);
                _Memo.Order1 = Convert.ToInt32(dt.Rows[cnt]["ORDER1"]);
                _Memo.Order2 = Convert.ToString(dt.Rows[cnt]["ORDER2"]);
                _Memo.Order3 = Convert.ToInt16(dt.Rows[cnt]["ORDER3"]);
                _Memo.CutDays2 = Convert.ToInt32(dt.Rows[cnt]["CutDays2"]);
                _Memo.CutMos2 = Convert.ToInt32(dt.Rows[cnt]["CutMos2"]);
                _Memo.MORule = Convert.ToString(dt.Rows[cnt]["MORULE"]);
                
                //--

                _Premium.PGROSSBASIS = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["PGROSSBASIS"]).ToString("#,##0.00"));
                _Premium.LEGALHRS = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["LEGALHRS"]).ToString("#,##0.00"));
                _Premium.SPECIALHRS = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["SPECIALHRS"]).ToString("#,##0.00"));
                _Premium.LEGALRESTHRS = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["LEGALRESTHRS"]).ToString("#,##0.00"));
                _Premium.SPECIALRESTHRS = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["SPECIALRESTHRS"]).ToString("#,##0.00"));
                _Premium.LEGALAMT = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["LEGALAMT"]).ToString("#,##0.00"));
                _Premium.SPECIALAMT = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["SPECIALAMT"]).ToString("#,##0.00"));
                _Premium.LEGALRESTAMT = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["LEGALRESTAMT"]).ToString("#,##0.00"));
                _Premium.SPECIALRESTAMT = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["SPECIALRESTAMT"]).ToString("#,##0.00"));
                _Premium.TOTLSAMT = Convert.ToString(Convert.ToDouble(dt.Rows[cnt]["TOTLSAMT"]).ToString("#,##0.00"));

                _Recom.LMOVENAT = Convert.ToString(dt.Rows[cnt]["LPROMDTE"]);
                if (dt.Rows[cnt]["EVALUDTE"].ToString() == "")
                    _Recom.EvaluationDate = "";
                else
                    _Recom.EvaluationDate = Convert.ToString(Convert.ToDateTime(dt.Rows[cnt]["EVALUDTE"]).ToString("MM/dd/yyy"));
                _Recom.PAR_C = Convert.ToString(dt.Rows[cnt]["PAR_C"]);
                _Recom.PAR_N = Convert.ToDouble(dt.Rows[cnt]["PAR_N"]);
                _Recom.BAREA = Convert.ToString(dt.Rows[cnt]["BAREA"]);
                _Recom.BELLPOSDESC = Convert.ToString(dt.Rows[cnt]["BELLPOSDESC"]);
                _Recom.TagProlonged = Convert.ToBoolean(dt.Rows[cnt]["TAGPROLONGED"]);
                _Recom.TagException = Convert.ToBoolean(dt.Rows[cnt]["TAGEXCEPTION"]);
                _Recom.IsProrated = Convert.ToBoolean(dt.Rows[cnt]["ISPRORATED"]);
                _Recom.TagAdvance = Convert.ToBoolean(dt.Rows[cnt]["TAGADVANCE"]);
                _Recom.LMOVENAT = Convert.ToString(dt.Rows[cnt]["LMOVENAT"]);
                _Recom.Recomd = Convert.ToString(dt.Rows[cnt]["Recomd"]);
                _Recom.BELLAREA = Convert.ToString(dt.Rows[cnt]["BELLAREA"]);
                _Recom.Rank = String.Format("{0}{1}{2}", Convert.ToString(dt.Rows[cnt]["NewPos"]), (Convert.ToString(dt.Rows[cnt]["NewPos"]).Length > 1 ? " | " : ""), Convert.ToString(dt.Rows[cnt]["NewPosDesc"]));

                _CurrentSalary.CurGross = Convert.ToDecimal(dt.Rows[cnt]["CURGROSS"]);
                _CurrentSalary.CurBasic = Convert.ToDecimal(dt.Rows[cnt]["CURBASIC"]);
                _CurrentSalary.CurRep = Convert.ToDecimal(dt.Rows[cnt]["CURREP"]);
                _CurrentSalary.CurTrav = Convert.ToDecimal(dt.Rows[cnt]["CURTRAV"]);
                _CurrentSalary.CurPa = Convert.ToDecimal(dt.Rows[cnt]["CURPA"]);
                _CurrentSalary.CurPacnt = Convert.ToDecimal(dt.Rows[cnt]["CURPACNT"]);
                _CurrentSalary.CurDitag = Convert.ToBoolean(dt.Rows[cnt]["CURDITAG"]);
                _CurrentSalary.CurDiamt = Convert.ToDecimal(dt.Rows[cnt]["CURDIAMT"]);
                _CurrentSalary.CurCreditRatio = Convert.ToDecimal(dt.Rows[cnt]["CURCREDITRATIO"]);
                _CurrentSalary.CurDiforce = Convert.ToBoolean(dt.Rows[cnt]["CURDIFORCE"]);
                _CurrentSalary.CurAlteredBasic = Convert.ToBoolean(dt.Rows[cnt]["CURALTEREDBASIC"]);
                _CurrentSalary.CurRule = Convert.ToString(dt.Rows[cnt]["CURRULE"]);

                _NewSalary.NewGross = Convert.ToDecimal(dt.Rows[cnt]["NEWGROSS"]);
                _NewSalary.NewBasic = Convert.ToDecimal(dt.Rows[cnt]["NEWBASIC"]);
                _NewSalary.NewRep = Convert.ToDecimal(dt.Rows[cnt]["NEWREP"]);
                _NewSalary.NewTrav = Convert.ToDecimal(dt.Rows[cnt]["NEWTRAV"]);
                _NewSalary.NewPa = Convert.ToDecimal(dt.Rows[cnt]["NEWPA"]);
                _NewSalary.NewPacnt = Convert.ToDecimal(dt.Rows[cnt]["NEWPACNT"]);
                _NewSalary.NewDitag = Convert.ToBoolean(dt.Rows[cnt]["NEWDITAG"]);
                _NewSalary.NewDiamt = Convert.ToDecimal(dt.Rows[cnt]["NEWDIAMT"]);
                _NewSalary.NewCreditRatio = Convert.ToDecimal(dt.Rows[cnt]["NEWCREDITRATIO"]);
                _NewSalary.NewDiforce = Convert.ToBoolean(dt.Rows[cnt]["NEWDIFORCE"]);
                _NewSalary.NewAlteredBasic = Convert.ToBoolean(dt.Rows[cnt]["NEWALTEREDBASIC"]);
                _NewSalary.NewRule = Convert.ToString(dt.Rows[cnt]["NEWRULE"]);

                _Increase.CurPct = Convert.ToDecimal(dt.Rows[cnt]["CURPCT"]);
                _Increase.CurConfAmt = Convert.ToDecimal(dt.Rows[cnt]["CURCONFAMT"]);
                _Increase.CurIncAmount = Convert.ToDecimal(dt.Rows[cnt]["CURINCAMT"]);
                _Increase.NewIncPct= Convert.ToDecimal(dt.Rows[cnt]["PCT"]);
                _Increase.NewIncConfAmt= Convert.ToDecimal(dt.Rows[cnt]["CONFAMT"]);
                _Increase.NewIncAmount = Convert.ToDecimal(dt.Rows[cnt]["INCAMT"]);

                _Details.Info = _Info;
                _Details.Bonus = _Bonus;
                _Details.Leaves = _Leave;
                _Details.MemoOnly = _Memo;
                _Details.Premium = _Premium;
                _Details.Recommendation = _Recom;
                _Details.CurrentSalary = _CurrentSalary;
                _Details.NewSalary = _NewSalary;
                _Details.Increase = _Increase;

            }
            return Json(_Details, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        //[Route("/Employee/ShowEmployeeInfo")]
        public JsonResult ShowEmployeeBonus(string EmployeeNo)
        {
            DataTable dt = new DataTable();
            InfoModel _model = new InfoModel();
            EmployeeSearchModel _searchmodel = new EmployeeSearchModel()
            {
                SearchKey = Enums.EmployeeSearchKey.Employeeno,
                SearchHint = EmployeeNo,
                PageIndex = 1,
                PageSize = 50,
                SearchEventOrigin = Enums.EmployeeSearchEventOrigin.SearchButton,
                InstanceGUID = Guid.NewGuid(),
                UserLevel = Enums.UserLevel.Level1
            };
            BusinessCore _core = new BusinessCore();
            int cnt = 0;
            dt = _core.GetEmployeeList(_searchmodel);
            if (dt.Rows.Count > 0)
            {
                _model.EmpNo = dt.Rows[cnt]["EmpNo"].ToString();
                _model.LastName = dt.Rows[cnt]["LastName"].ToString();
                _model.FirstName = dt.Rows[cnt]["FirstName"].ToString();
                _model.MiddleName = dt.Rows[cnt]["MiddleName"].ToString();
                _model.SGVNo = dt.Rows[cnt]["SGVNo"].ToString();
                _model.Position = dt.Rows[cnt]["Pos"].ToString();
                _model.PositionDesc = dt.Rows[cnt]["PosDesc"].ToString();
                _model.DateHired = dt.Rows[cnt]["DateHired"].ToString();
                _model.DateResigned = dt.Rows[cnt]["DateResigned"].ToString();
                _model.TagVP = dt.Rows[cnt]["TagVP"].ToString();
                _model.TagVPDate = dt.Rows[cnt]["TagVPDate"].ToString();
                _model.PageNo = 1;
                _model.PageSize = 50;
            }
            return Json(_model, JsonRequestBehavior.AllowGet);
        }

        public int UpdateEmployeeBonus(BonusModel Bonus)
        {
            int cnt = 0;
            try
            {
                if (Bonus != null)
                {
                    BonusModel _bonusmodel = new BonusModel()
                    {
                        EmpNo = Bonus.EmpNo,
                        ResultGross = Bonus.ResultGross,
                        ResultBasic = Bonus.ResultBasic,
                        ResultRRA = Bonus.ResultRRA,
                        ResultTA = Bonus.ResultTA,
                        BonusGross = Bonus.BonusGross,
                        BonusBasic = Bonus.BonusBasic,
                        BonusRRA = Bonus.BonusRRA,
                        BonusTA = Bonus.BonusTA,
                        CCardAmount = Bonus.CCardAmount,
                        CorpCard = Bonus.CorpCard,
                        ForceCCard = Bonus.ForceCCard,
                        ForceBasic = Bonus.ForceBasic,
                    };
                    BusinessCore _core = new BusinessCore();
                    cnt = _core.UpdateEmployeeBonus(_bonusmodel);
                }
            }catch(Exception ex)
            {
                throw ex;
            }
            return cnt;
        }

        //[HttpGet]
        //public JsonResult ShowEmployee(int PageNo, int PageSize)
        //{
        //    int _PageNo = PageNo;
        //    int _PageSize = PageSize;
        //    DataTable dt = new DataTable();
        //    List<InfoModel> _listmodel = new List<InfoModel>();
        //    EmployeeSearchModel _searchmodel = new EmployeeSearchModel()
        //    {
        //        SearchKey = Enums.EmployeeSearchKey.Lastname,
        //        SearchHint = "",
        //        PageIndex = _PageNo,
        //        PageSize = _PageSize,
        //        SearchEventOrigin = Enums.EmployeeSearchEventOrigin.SearchButton,
        //        InstanceGUID = Guid.NewGuid(),
        //        UserLevel = Enums.UserLevel.Level1
        //    };
        //    BusinessCore _core = new BusinessCore();
        //    dt = _core.GetEmployeeList(_searchmodel);
        //    if (dt.Rows.Count > 0)
        //    {
        //        for (int cnt = 0; cnt <= dt.Rows.Count - 1; cnt++)
        //        {
        //            InfoModel _model = new InfoModel();
        //            _model.EmpNo = dt.Rows[cnt]["EmpNo"].ToString();
        //            _model.LastName = dt.Rows[cnt]["LastName"].ToString();
        //            _model.FirstName = dt.Rows[cnt]["FirstName"].ToString();
        //            _model.MiddleName = dt.Rows[cnt]["MiddleName"].ToString();
        //            _model.PageNo = _PageNo;
        //            _model.PageSize = _PageSize;
        //            _listmodel.Add(_model);
        //        }
        //    }
        //    return Json(_listmodel, JsonRequestBehavior.AllowGet);
        //}

        //// GET: Employee/Details/5
        //public ActionResult Details(int id)
        //{
        //    return View();
        //}

        //// GET: Employee/Create
        //public ActionResult Create()
        //{
        //    return View();
        //}

        //// POST: Employee/Create
        //[HttpPost]
        //public ActionResult Create(FormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add insert logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        //// GET: Employee/Edit/5
        //public ActionResult Edit(int id)
        //{
        //    return View();
        //}

        //// POST: Employee/Edit/5
        //[HttpPost]
        //public ActionResult Edit(int id, FormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add update logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        //// GET: Employee/Delete/5
        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //// POST: Employee/Delete/5
        //[HttpPost]
        //public ActionResult Delete(int id, FormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add delete logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
    }
}
