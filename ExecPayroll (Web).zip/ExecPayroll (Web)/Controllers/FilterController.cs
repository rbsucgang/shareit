﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ExecPayroll_Web.Model;
using ExecPayroll_Web.BLL;
using ExecPayroll_Web.Models;
using ExecPayroll_Web.Generic;
using System.Data;


namespace ExecPayroll_Web.Controllers
{
    public class FilterController : Controller
    {
        // GET: Filter
        public ActionResult PartialFilter()
        {
            return View();
        }

        [HttpGet]
        public JsonResult InitFilterDropDownList(int FilterIdParam)
        {
            List<GenericModel> _Generic = new List<GenericModel>();
            GenericBLL _List = new GenericBLL();
            _Generic = _List.lstGenericCollection("Filter", 2, Enums.UserLevel.Level1);
            var obj = _Generic.Where(x => (x.FilteredID == 0 || x.FilteredID == FilterIdParam)).ToList();
            return Json(obj, JsonRequestBehavior.AllowGet);
        }


        //[HttpPost]
        //public JsonResult GetFilteredEmployeeList(FilterQryModel data)
        //{
        //    DataTable dt = new DataTable();
        //    FilterBLL _List = new FilterBLL();
        //    data.UserLevel = Enums.UserLevel.Level1.ToString();
        //    dt = _List.FilterEmployeeList(data);

        //    var obj = dt; 
        //    return Json(obj, JsonRequestBehavior.AllowGet);
        //}

        [HttpPost]
        public JsonResult GetFilteredEmployeeList(
            string UserLevel, bool IncludeCurGross, bool IncludeNewGross
            , int other3, int other2, int other, int ESL
            , int INC, int CG, int NOD, int NLD
            , int NBD, int ZOA, int ZLA, int ZBA
            , int NS, int OS, int ZNB, int ZNG
            , int ResM, int HM, int ZOB, int ZOG
            , int Subsidiary, int Recom, int RM, int Rank
            )
        {
            DataTable dt = new DataTable();
            FilterBLL _List = new FilterBLL();
            List<InfoModel> _listmodel = new List<InfoModel>();
            FilterQryModel data = new FilterQryModel();
            data.UserLevel = Enums.UserLevel.Level1.ToString(); data.ExportIncludeCurGross = IncludeCurGross; data.ExportIncludeNewGross = IncludeNewGross
            ; data.Other3 = other3; data.Other2 = other2; data.Other = other; data.ESL = ESL
               ; data.Inc = INC; data.CG = CG; data.NOD = NOD; data.NLD = NLD
                   ; data.NBD = NBD; data.ZOA = ZOA; data.ZLA = ZLA; data.ZBA = ZBA
                       ; data.NS = NS; data.OS = OS; data.ZNB = ZNB; data.ZNG = ZNG
                           ; data.ResM = ResM; data.HM = HM; data.ZOB = ZOB; data.ZOG = ZOG
                               ; data.Subsidiary = Subsidiary; data.Recom = Recom; data.RM = RM; data.Rank = Rank;

            dt = _List.FilterEmployeeList(data);
            if (dt.Rows.Count > 0)
            {
                for (int cnt = 0; cnt <= dt.Rows.Count - 1; cnt++)
                {
                    InfoModel _model = new InfoModel();
                    _model.EmpNo = Convert.ToString(dt.Rows[cnt]["EmpNo"]);
                    _model.LastName = Convert.ToString(dt.Rows[cnt]["LastName"]);
                    _model.FirstName = Convert.ToString(dt.Rows[cnt]["FirstName"]);
                    _model.MiddleName = Convert.ToString(dt.Rows[cnt]["MiddleName"]);
                    _model.DateHired = Convert.ToString(Convert.ToDateTime(dt.Rows[cnt]["DateHired"]).ToString("MM/dd/yyyy"));
                    _model.DateResigned = Convert.ToString(Convert.ToDateTime(dt.Rows[cnt]["DateResigned"]).ToString("MM/dd/yyyy"));
                    _model.TagVP = Convert.ToString(dt.Rows[cnt]["TagVP"]);
                    _model.TagVPDate = Convert.ToString(Convert.ToDateTime(dt.Rows[cnt]["TagVPDate"]).ToString("MM/dd/yyyy"));
                    _model.PageNo = 1;
                    _model.PageSize = 50;
                    _listmodel.Add(_model);
                }
            }
            return Json(_listmodel, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult ProcessArchive(
            string UserLevel, bool IncludeCurGross, bool IncludeNewGross
            , int other3, int other2, int other, int ESL
            , int INC, int CG, int NOD, int NLD
            , int NBD, int ZOA, int ZLA, int ZBA
            , int NS, int OS, int ZNB, int ZNG
            , int ResM, int HM, int ZOB, int ZOG
            , int Subsidiary, int Recom, int RM, int Rank
            )
        {

            DataSet ds = new DataSet();
            DataTable dt;
            FilterBLL _List = new FilterBLL();
            ArchiveParamModel data = new ArchiveParamModel();

            data.ARCHIVETABLE = ""; data.ISTAGVP = 0; data.SEARCHHINT = ""; data.SearchKey = 81;
            data.UserLevel = Enums.UserLevel.Level1.ToString(); data.ExportIncludeCurGross = IncludeCurGross; data.ExportIncludeNewGross = IncludeNewGross
            ; data.Other3 = other3; data.Other2 = other2; data.Other = other; data.ESL = ESL
               ; data.Inc = INC; data.CG = CG; data.NOD = NOD; data.NLD = NLD
                   ; data.NBD = NBD; data.ZOA = ZOA; data.ZLA = ZLA; data.ZBA = ZBA
                       ; data.NS = NS; data.OS = OS; data.ZNB = ZNB; data.ZNG = ZNG
                           ; data.ResM = ResM; data.HM = HM; data.ZOB = ZOB; data.ZOG = ZOG
                               ; data.Subsidiary = Subsidiary; data.Recom = Recom; data.RM = RM; data.Rank = Rank;
            ds = _List.GenerateArchive(data);
            // DEPENDCY TO ROEL
            //// wait for ruel to finish the DLL for export to excel ..

            // the process the export to excel here
            //this.ExportToExcel(ds,path); 
            // the process the export to excel here
            return Json("success", JsonRequestBehavior.AllowGet);
        }

        //this is just a test method.. will be waiting for roel to complete the export to excel
        //private void ExportToExcel(DataTable dt)
        //{
        //    //dt = city.GetAllCity();//your datatable
        //    //string attachment = "attachment; filename=C:\\_dumpfiles\\city.xls";
        //    string attachment = "attachment;filename=\"Samplefile.xlsx\"";
        //    //httpResponse.AddHeader("content-disposition", "attachment;filename=\"Samplefile.xlsx\"");

        //    Response.ClearContent();
        //    Response.AddHeader("content-disposition", attachment);
        //    Response.ContentType = "application/vnd.ms-excel";
        //    string tab = "";
        //    foreach (DataColumn dc in dt.Columns)
        //    {
        //        Response.Write(tab + dc.ColumnName);
        //        tab = "\t";
        //    }
        //    Response.Write("\n");
        //    int i;
        //    foreach (DataRow dr in dt.Rows)
        //    {
        //        tab = "";
        //        for (i = 0; i < dt.Columns.Count; i++)
        //        {
        //            Response.Write(tab + dr[i].ToString());
        //            tab = "\t";
        //        }
        //        Response.Write("\n");
        //    }
        //    Response.End();
        //}

    }
}