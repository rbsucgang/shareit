﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using ExecPayroll_Web.Controllers;
using ExecPayroll_Web.Model;

using ExecPayroll_Web.BLL;
using ExecPayroll_Web.Models;
using ExecPayroll_Web.Generic;
using System.Data;

namespace ExecPayroll_Web.Controllers
{
    public class LeavesController : Controller
    {
        // GET: Leaves
        public ActionResult PartialLeaves()
        {

            InfoModel _model = new InfoModel();
            EmployeeSearchModel _searchmodel = new EmployeeSearchModel()
            {
                SearchKey = Enums.EmployeeSearchKey.All,
                SearchHint = "",
                PageIndex = 1,
                PageSize = 50,
                SearchEventOrigin = Enums.EmployeeSearchEventOrigin.FilterTab,
                InstanceGUID = Guid.NewGuid(),
                UserLevel = Enums.UserLevel.Level1
            };
            BusinessCore _core = new BusinessCore();
            // _model = _core.GetEmployeeList(_searchmodel);
            return View();
        }

        [HttpGet]
        public JsonResult ComputeLeaves(string NEWGROSS, string NONT_VL, string TAXB_VL, string TAXB_SL)
        {
            LeavesModel obj = new LeavesModel();
            DataTable dt = new DataTable();
            BusinessCore _core = new BusinessCore();
            LeaveParamchModel _param = new LeaveParamchModel();
            _param.NEWGROSS = NEWGROSS;
            _param.NONT_VL = NONT_VL;
            _param.TAXB_VL = TAXB_VL;
            _param.TAXB_SL = TAXB_SL;
            dt = _core.GetLeaveComputation(_param);

            obj.NONT_AMT = dt.Rows[0]["NONT_AMT"].ToString();
            obj.TAXB_AMT = dt.Rows[0]["TAXB_AMT"].ToString();
            obj.VLSL_TX = dt.Rows[0]["VLSL_TX"].ToString();
            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult GetLeaves()
        {
            List<LeavesModel> obj = new List<LeavesModel>
            {
                new LeavesModel { NEWGROSS="111" },
                new LeavesModel { NONT_VL="111" },
                new LeavesModel { NONT_AMT="111" },
                new LeavesModel { TAXB_VL="111" },
                new LeavesModel { TAXB_SL ="111"},
                new LeavesModel { VLSL_TX="111" },
                new LeavesModel { TAXB_AMT="111" },
            };
            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult TestFnc(LeavesModel obj)
        {
            return View();
        }

    }
}