﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data.SqlClient;


namespace ExportExcelMultipleWorkSheets
{
    class BackupOriginal
    {

    //Create a DataSet with the existing DataTables
    DataSet ds = new DataSet("Organization");
    private void CreateDataset()
    {
        //Create an Emplyee DataTable
        DataTable employeeTable = new DataTable("Employee");
        employeeTable.Columns.Add("Employee ID");
        employeeTable.Columns.Add("Employee Name");
        employeeTable.Rows.Add("1", "ABC");
        employeeTable.Rows.Add("2", "DEF");
        employeeTable.Rows.Add("3", "PQR");
        employeeTable.Rows.Add("4", "XYZ");

        //Create a Department Table
        DataTable departmentTable = new DataTable("Department");
        departmentTable.Columns.Add("Department ID");
        departmentTable.Columns.Add("Department Name");
        departmentTable.Rows.Add("1", "IT");
        departmentTable.Rows.Add("2", "HR");
        departmentTable.Rows.Add("3", "Finance");


        ds.Tables.Add(employeeTable);
        ds.Tables.Add(departmentTable);

        //ExportDataSetToExcel(ds);
    }

    private void ExportDataSetToExcel()
    {

        System.Collections.ArrayList SheetObj = new System.Collections.ArrayList();
        SheetObj.Add("HR_ADMIN");

        System.Collections.ArrayList HdrObj = new System.Collections.ArrayList();
        HdrObj.Add("CONTACT NAME");
        HdrObj.Add("BRANCH");

        System.Collections.ArrayList DetObj = new System.Collections.ArrayList();
        DetObj.Add("CONTACT_NAME");
        DetObj.Add("BRANCH");


        StaffBLL obj = new StaffBLL();
        System.Data.DataTable dt = new System.Data.DataTable();
        //Creae an Excel application instance
        Excel.Application excelApp = new Excel.Application();
        //Create an Excel workbook instance and open it from the predefined location
        Excel.Workbook excelWorkBook;
        try
        {
            dt = obj.ReturnDataTable();
            excelWorkBook = excelApp.Workbooks.Open(@"C:\AAA\book1.xlsx");
            Excel.Worksheet excelWorkSheet = excelWorkBook.Sheets.Add();
            excelWorkSheet.Name = "HELLOWORLD";

            int HrdCtr = 1;
            foreach (var item in HdrObj)
            {
                excelWorkSheet.Cells[1, HrdCtr] = item;
                HrdCtr++;
            }
            //excelWorkSheet.Cells[1, 1] = "CONTACT NAME";
            //excelWorkSheet.Columns["A"].ColumnWidth = 50;
            //excelWorkSheet.Columns["B"].ColumnWidth = 50;
            //excelWorkSheet.Cells[1, 2] = "BRANCH";

            int x = 2;
            for (int i = 0; i < dt.Rows.Count - 1; i++)
            {
                //excelWorkSheet.Cells[x, 1] = dt.Rows[i]["CONTACT_NAME"].ToString();
                //excelWorkSheet.Cells[x, 2] = dt.Rows[i]["BRANCH"].ToString();
                int colCtr = 1;
                foreach (string item in DetObj)
                {
                    excelWorkSheet.Cells[x, colCtr] = dt.Rows[i][item].ToString();
                    colCtr++;
                }
                x++;
            }
            excelApp.DisplayAlerts = false;
            excelApp.Visible = true;
            excelWorkBook.Save();
            excelWorkBook.Close();
        }
        catch (Exception ex)
        {

        }
        finally
        {
            excelApp.Quit();
            excelApp = null;
        }


    }
}

}

/*
 using System.Data;
using Excel = Microsoft.Office.Interop.Excel;

namespace ExportDataSetToExcel
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();

            //Create an Emplyee DataTable
            DataTable employeeTable = new DataTable("Employee");
            employeeTable.Columns.Add("Employee ID");
            employeeTable.Columns.Add("Employee Name");
            employeeTable.Rows.Add("1", "ABC");
            employeeTable.Rows.Add("2", "DEF");
            employeeTable.Rows.Add("3", "PQR");
            employeeTable.Rows.Add("4", "XYZ");

            //Create a Department Table
            DataTable departmentTable = new DataTable("Department");
            departmentTable.Columns.Add("Department ID");
            departmentTable.Columns.Add("Department Name");
            departmentTable.Rows.Add("1", "IT");
            departmentTable.Rows.Add("2", "HR");
            departmentTable.Rows.Add("3", "Finance");

            //Create a DataSet with the existing DataTables
            DataSet ds = new DataSet("Organization");
            ds.Tables.Add(employeeTable);
            ds.Tables.Add(departmentTable);

            p.ExportDataSetToExcel(ds);
        }

        /// &lt;summary>
        /// This method takes DataSet as input paramenter and it exports the same to excel
        /// &lt;/summary>
        /// &lt;param name="ds">&lt;/param>
        private void ExportDataSetToExcel(DataSet ds)
        {
            //Creae an Excel application instance
            Excel.Application excelApp = new Excel.Application();
            
            //Create an Excel workbook instance and open it from the predefined location
            Excel.Workbook excelWorkBook = excelApp.Workbooks.Open(@"E:\Org.xlsx");

            foreach (DataTable table in ds.Tables)
            {
                //Add a new worksheet to workbook with the Datatable name
                Excel.Worksheet excelWorkSheet = excelWorkBook.Sheets.Add();
                excelWorkSheet.Name = table.TableName;

                for (int i = 1; i &lt; table.Columns.Count + 1; i++)
                {
                    excelWorkSheet.Cells[1, i] = table.Columns[i - 1].ColumnName;
                }

                for (int j = 0; j &lt; table.Rows.Count; j++)
                {
                    for (int k = 0; k &lt; table.Columns.Count; k++)
                    {
                        excelWorkSheet.Cells[j + 2, k + 1] = table.Rows[j].ItemArray[k].ToString();
                    }
                }
            }

            excelWorkBook.Save();
            excelWorkBook.Close();
            excelApp.Quit();

        }
    }
}


 */
