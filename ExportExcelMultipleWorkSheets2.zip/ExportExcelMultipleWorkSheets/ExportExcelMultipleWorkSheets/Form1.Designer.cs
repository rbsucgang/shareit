﻿namespace ExportExcelMultipleWorkSheets
{
    partial class ExportToExcelFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ExportToExcelBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ExportToExcelBtn
            // 
            this.ExportToExcelBtn.Location = new System.Drawing.Point(303, 99);
            this.ExportToExcelBtn.Name = "ExportToExcelBtn";
            this.ExportToExcelBtn.Size = new System.Drawing.Size(132, 21);
            this.ExportToExcelBtn.TabIndex = 0;
            this.ExportToExcelBtn.Text = "EXPORT TO EXCEL";
            this.ExportToExcelBtn.UseVisualStyleBackColor = true;
            this.ExportToExcelBtn.Click += new System.EventHandler(this.ExportToExcelBtn_Click);
            // 
            // ExportToExcelFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(447, 132);
            this.Controls.Add(this.ExportToExcelBtn);
            this.Name = "ExportToExcelFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Export Excel";
            this.Load += new System.EventHandler(this.ExportToExcelFrm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ExportToExcelBtn;
    }
}

