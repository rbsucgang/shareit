﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;


namespace ExportExcelMultipleWorkSheets
{
    public class StaffBLL
    {
        SqlParameter[] sqlParam;
        public DataTable ReturnDataTable()
        {
            DataTable dt = new DataTable();
            try
            {
                Array.Resize(ref sqlParam, 3);
                DataAccess dObj = new DataAccess();
                /*
                sqlParam[0] = new SqlParameter("@EmployeeName", SqlDbType.NVarChar, 50, ParameterDirection.Input,
                                                        false, 0, 0, "", DataRowVersion.Current, Nm);
                sqlParam[1] = new SqlParameter("@Salary", SqlDbType.Decimal, 8, ParameterDirection.Input,
                                                        false, 0, 0, "", DataRowVersion.Current, Sal);
                */
                dt = dObj.ReturnDataTable("uspTest", sqlParam);
            }
            catch (Exception ex)
            {
                return null;
            }
            return dt;

        }

    }
}
