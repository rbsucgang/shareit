﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace ExportExcelMultipleWorkSheets
{
    public class DataAccess
    {
        System.Data.SqlClient.SqlConnection CN;
        string cnStr = "Data Source=RUEL-PC;Initial Catalog=TESTDB;Persist Security Info=True;User ID=sa;Password=devteam";


        public DataSet ReturnDT(string sp, System.Data.SqlClient.SqlParameter[] sqlParam)
        {
            DataSet ds = new DataSet();
            CN = new SqlConnection(cnStr);
            SqlDataAdapter da = new SqlDataAdapter();
            SqlCommand cmd = new SqlCommand();
            try
            {
                cmd.CommandText = sp;
                cmd.Connection = CN;
                CN.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 600000;

                if (sqlParam.Length > 0)
                {
                    for (int i = 0; i < sqlParam.Length - 1; i++)
                    {
                        cmd.Parameters.Add(sqlParam[i]);
                    };
                }
                cmd.Prepare();
                da.SelectCommand = cmd;
                da.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                CN.Close();
            }
        }



        public DataTable ReturnDataTable(string sp, System.Data.SqlClient.SqlParameter[] sqlParam)
        {
            DataTable dt = new DataTable();
            CN = new SqlConnection(cnStr);
            SqlDataAdapter da = new SqlDataAdapter();
            SqlCommand cmd = new SqlCommand();
            try
            {
                cmd.CommandText = sp;
                cmd.Connection = CN;
                CN.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 600000;

                //if (sqlParam.Length > 0)
                //{
                //    for (int i = 0; i < sqlParam.Length - 1; i++)
                //    {
                //        cmd.Parameters.Add(sqlParam[i]);
                //    };
                //}
                cmd.Prepare();
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                CN.Close();
            }
        }

        public bool ExecuteNonQuery(string sp, System.Data.SqlClient.SqlParameter[] sqlParam)
        {
            CN = new SqlConnection(cnStr);
            SqlDataAdapter da = new SqlDataAdapter();
            SqlCommand cmd = new SqlCommand();
            try
            {
                cmd.CommandText = sp;
                CN.Open();
                cmd.Connection = CN;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 600000;

                if (sqlParam.Length > 0)
                {
                    for (int i = 0; i < sqlParam.Length - 1; i++)
                    {
                        cmd.Parameters.Add(sqlParam[i]);
                    };
                }
                cmd.Prepare();
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                CN.Close();
            }

        }

    }
}
