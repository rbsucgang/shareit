﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data.SqlClient;


namespace ExportExcelMultipleWorkSheets
{
    public partial class ExportToExcelFrm : Form
    {
        public ExportToExcelFrm()
        {
            InitializeComponent();
        }

        private void ExportToExcelFrm_Load(object sender, EventArgs e)
        {


        }
        private void ExportToExcelBtn_Click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            GetDataSet dsObj = new GetDataSet();
            ds = dsObj.CreateDataset();

            bool returnedstatus =false;
            System.Collections.ArrayList SheetObj;
            System.Collections.ArrayList HdrObj;
            System.Collections.ArrayList DetObj;
            for (int TblCtr = 0; TblCtr < ds.Tables.Count; TblCtr++)
            {
                SheetObj = new System.Collections.ArrayList();
                SheetObj.Add(ds.Tables[TblCtr].TableName);

                HdrObj = new System.Collections.ArrayList();
                for (int i = 1; i < ds.Tables[TblCtr].Columns.Count + 1; i++)
                {
                    HdrObj.Add(ds.Tables[TblCtr].Columns[i - 1].ColumnName);
                }
                DetObj = new System.Collections.ArrayList();
                for (int i = 1; i < ds.Tables[TblCtr].Columns.Count + 1; i++)
                {
                    DetObj.Add(ds.Tables[TblCtr].Columns[i - 1].ColumnName);
                }
                string FName = CreateExcelFile();
                returnedstatus = ExportDataSetToExcel(ds.Tables[TblCtr], FName, SheetObj, HdrObj, DetObj);
                SheetObj = null; HdrObj = null; DetObj = null;
            }

            if (returnedstatus) { MessageBox.Show("Success"); } else { MessageBox.Show("Failed!"); };
            
        }

        private string CreateExcelFile()
        {
            return @"C:\AAA\book1.xlsx";
        }
        private bool ExportDataSetToExcel(DataTable dt, string FName, System.Collections.ArrayList SheetObj, System.Collections.ArrayList HdrObj, System.Collections.ArrayList DetObj)
        {
            //Creae an Excel application instance
            Excel.Application excelApp = new Excel.Application();
            //Create an Excel workbook instance and open it from the predefined location
            Excel.Workbook excelWorkBook;
            excelWorkBook = excelApp.Workbooks.Open(FName);

            foreach (string sheetName in SheetObj)
            {
                try
                {
                    Excel.Worksheet excelWorkSheet = excelWorkBook.Sheets.Add();
                    excelWorkSheet.Name = sheetName;
                    int HrdCtr = 1;
                    foreach (var item in HdrObj)
                    {
                        excelWorkSheet.Cells[1, HrdCtr] = item;
                        HrdCtr++;
                    }
                    int x = 2;
                    for (int i = 0; i < dt.Rows.Count - 1; i++)
                    {
                        int colCtr = 1;
                        foreach (string item in DetObj)
                        {
                            excelWorkSheet.Cells[x, colCtr] = dt.Rows[i][item].ToString();
                            colCtr++;
                        }
                        x++;
                    }
                    excelApp.DisplayAlerts = false;
                    excelApp.Visible = false;
                }
                catch (Exception ex)
                {
                    return false;
                }
            }
            excelWorkBook.Save();
            excelWorkBook.Close();
            excelApp.Quit();
            excelApp = null;
            return true;
        }
    }
}
